import fs from 'node:fs';
import crypto from 'node:crypto';
import { registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
const base='D:/codex/2026-11-16/world-implementation/world-base/apps/desktop/e2e/fixtures/world-base';
registerHooks({resolve(s,c,next){
  if(s==='three')return {url:pathToFileURL(base+'/upstream/petalwake/vendor/three/build/three.module.js').href,shortCircuit:true};
  return next(s,c);
}});
const THREE=await import('three');
const {Meadow}=await import(pathToFileURL(base+'/upstream/petalwake/src/world/meadow.js'));
const {createLook}=await import(pathToFileURL(base+'/src/look.js'));
const renderer={capabilities:{reversedDepthBuffer:false}};
const camera=new THREE.PerspectiveCamera(50,1,.1,2000);
const terrainText='void main(){\nfloat dif = saturate((ndlRaw + 0.32 * soft) / (1.0 + 0.32 * soft));\nvec3 tint = meadowTint(P.xz, wet);\ntintAmt *= 1.0 - strippedFiltered(uv);\n}';
const mat=s=>new THREE.ShaderMaterial({fragmentShader:s,uniforms:{}});
function makeIsland(){
  const terrain={splatN:1,splat:new Uint8Array([255,0,0,255]),heightAt:()=>0,material:mat(terrainText)};
  return {terrain,meadow:new Meadow(terrain,'medium'),transition:{material:mat(terrainText)},town:{material:mat('void main(){float dif = saturate(ndl);}')},water:{material:mat('vec3 shallow = vec3(0.030, 0.420, 0.380);\nvec3 P = vWorld;\nfloat pathLen = depth * 1.;\nfloat foam = max(max(cap, surfBand * 0.9), max(lace, churn));')}};
}
const result={scope:'CPU only: real Three r187, Pipeline constructor, createLook, Meadow and Shell material factory. Non-meadow island shaders are minimal insertion fixtures, not compiled; no renderer or GPU called.',sourceHashes:{}};
for(const p of ['src/look.js','src/main.js','src/island.js','upstream/petalwake/src/world/meadow.js','upstream/petalwake/src/core/pipeline.js'])result.sourceHashes[p]=crypto.createHash('sha256').update(fs.readFileSync(base+'/'+p)).digest('hex');
const A=createLook(renderer,camera), a=makeIsland();
result.firstPoolEmpty=a.meadow.shells.every(s=>s.pool.length===0);
A.applyIsland(a);A.setTownGreenery([10,20,30,40],.6);
const grassA=a.meadow.shells.find(s=>s.kind==='grass').mesh(0).material;
const flowerA=a.meadow.shells.find(s=>s.kind==='flower').mesh(0).material;
result.first={grassRect:grassA.uniforms.uTownRect.value.toArray(),flowerRect:flowerA.uniforms.uTownRect.value.toArray(),sameUniform:grassA.uniforms.uTownRect===a.terrain.material.uniforms.uTownRect,townFunctionCounts:[grassA,flowerA].map(m=>(m.vertexShader.match(/float wbTownMask\(/g)||[]).length)};
A.setTownGreenery([10,20,30,40],0);
result.firstDisable=[grassA,flowerA].map(m=>m.uniforms.uTownGreen.value.x);
let disposedA=0;grassA.addEventListener('dispose',()=>disposedA++);
a.meadow.setQuality('medium');
const rebuiltA=a.meadow.shells[0].mesh(0).material;
result.sameLookQualityRebuild={oldGrassDisposed:disposedA,newMaterial:rebuiltA!==grassA,ownerCorrect:rebuiltA.uniforms.uTownRect===a.terrain.material.uniforms.uTownRect};
const B=createLook(renderer,camera),b=makeIsland();
const prebuilt=b.meadow.shells[0].mesh(0);
prebuilt.material.uniforms.uCell.value.set(100,200,30,.3);
const oldB=prebuilt.material;let disposedB=0;oldB.addEventListener('dispose',()=>disposedB++);
B.applyIsland(b);B.setTownGreenery([110,120,130,140],.75);
const grassB=prebuilt.material;
result.second={terrainRect:b.terrain.material.uniforms.uTownRect.value.toArray(),meadowRect:grassB.uniforms.uTownRect.value.toArray(),meadowStrength:grassB.uniforms.uTownGreen.value.x,usesFirstLook:grassB.uniforms.uTownRect===a.terrain.material.uniforms.uTownRect,usesOwnLook:grassB.uniforms.uTownRect===b.terrain.material.uniforms.uTownRect,oldMaterialDisposed:disposedB,replacementUCell:grassB.uniforms.uCell.value.toArray()};
A.setTownGreenery([-1,-2,1,2],.9);
result.firstSetterChangesSecond={rect:grassB.uniforms.uTownRect.value.toArray(),strength:grassB.uniforms.uTownGreen.value.x};
B.setTownGreenery([110,120,130,140],0);
result.secondDisable={terrainStrength:b.terrain.material.uniforms.uTownGreen.value.x,meadowStrength:grassB.uniforms.uTownGreen.value.x};
b.meadow.setQuality('medium');
result.secondQualityRebuildStillUsesFirst=b.meadow.shells[0].mesh(0).material.uniforms.uTownRect===a.terrain.material.uniforms.uTownRect;
const c=makeIsland();
result.unadaptedThirdMeadowUsesFirst=c.meadow.shells[0].mesh(0).material.uniforms.uTownRect===a.terrain.material.uniforms.uTownRect;
for(const island of [a,b,c]){for(const s of island.meadow.shells){for(const m of s.pool)m.material.dispose();s.geo.dispose();}for(const k of ['terrain','transition','town','water'])island[k].material.dispose();}
for(const look of [A,B]){look.pipeline.dispose();for(const k of ['blurMat','copyMat','downMat','upMat','raysMat','finalMat'])look.pipeline[k].dispose();}
console.log(JSON.stringify(result,null,2));
