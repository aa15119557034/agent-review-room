import fs from 'node:fs';
import crypto from 'node:crypto';
import { registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
const base='D:/codex/2026-11-16/world-implementation/world-base/apps/desktop/e2e/fixtures/world-base';
registerHooks({resolve(s,c,next){
  if(s==='three')return {url:pathToFileURL(base+'/upstream/petalwake/vendor/three/build/three.module.js').href,shortCircuit:true};
  return next(s,c);
}});
const THREE=await import('three');
const {Meadow}=await import(pathToFileURL(base+'/upstream/petalwake/src/world/meadow.js'));
const {createLook}=await import(pathToFileURL(base+'/src/look.js'));
const renderer={capabilities:{reversedDepthBuffer:false}};
const camera=new THREE.PerspectiveCamera(50,1,.1,2000);
const terrainText='void main(){\nfloat dif = saturate((ndlRaw + 0.32 * soft) / (1.0 + 0.32 * soft));\nvec3 tint = meadowTint(P.xz, wet);\ntintAmt *= 1.0 - strippedFiltered(uv);\n}';
const mat=s=>new THREE.ShaderMaterial({fragmentShader:s,uniforms:{}});
function makeIsland(){
  const terrain={splatN:1,splat:new Uint8Array([255,0,0,255]),heightAt:()=>0,material:mat(terrainText)};
  return {terrain,meadow:new Meadow(terrain,'medium'),transition:{material:mat(terrainText)},town:{material:mat('void main(){float dif = saturate(ndl);}')},water:{material:mat('vec3 shallow = vec3(0.030, 0.420, 0.380);\nvec3 P = vWorld;\nfloat pathLen = depth * 1.;\nfloat foam = max(max(cap, surfBand * 0.9), max(lace, churn));')}};
}
import assert from 'node:assert/strict';
const result={schema:'x51-c17-meadow-lifecycle-v1',sourceHead:'0184c79d94094c7d76378302592572bf367be6c7',scope:'CPU only: real Three r187, Pipeline constructor, createLook, Meadow and Shell material factory. Non-meadow island shaders are minimal insertion fixtures, not compiled. No renderer/GPU, complete scene, image pixels or leak test.',sourceHashes:{},checks:[]};
for(const p of ['src/look.js','src/main.js','src/island.js','upstream/petalwake/src/world/meadow.js','upstream/petalwake/src/core/pipeline.js'])result.sourceHashes[p]=crypto.createHash('sha256').update(fs.readFileSync(base+'/'+p)).digest('hex');
const islands=[],looks=[];
function island(){const i=makeIsland();islands.push(i);return i;}
function look(){const l=createLook(renderer,camera);looks.push(l);return l;}
function check(name,fn){fn();result.checks.push({name,passed:true});}
function materials(i){return ['grass','flower'].map(kind=>i.meadow.shells.find(s=>s.kind===kind).mesh(0).material);}
function bound(ms,owner,rect,strength){for(const m of ms){assert.equal(m.uniforms.uTownRect,owner.terrain.material.uniforms.uTownRect);assert.equal(m.uniforms.uTownGreen,owner.terrain.material.uniforms.uTownGreen);assert.deepEqual(m.uniforms.uTownRect.value.toArray(),rect);assert.equal(m.uniforms.uTownGreen.value.x,strength);assert.equal((m.vertexShader.match(/float wbTownMask\(/g)||[]).length,1);}}
try{
 const A=look(),a=island(),original=Object.getPrototypeOf(a.meadow.shells[0]).material;
 check('first init has empty pools',()=>assert(a.meadow.shells.every(s=>s.pool.length===0)));
 A.applyIsland(a);A.setTownGreenery([10,20,30,40],.6);
 const am=materials(a);
 check('first grass/flower share A uniforms and single injection',()=>bound(am,a,[10,20,30,40],.6));
 check('terrain and transition share town uniform objects',()=>{assert.equal(a.transition.material.uniforms.uTownRect,a.terrain.material.uniforms.uTownRect);assert.equal(a.transition.material.uniforms.uTownGreen,a.terrain.material.uniforms.uTownGreen);assert.equal((a.transition.material.fragmentShader.match(/float wbTownMask\(/g)||[]).length,1);});
 A.setTownGreenery([10,20,30,40],0);
 check('first look disable works',()=>bound(am,a,[10,20,30,40],0));
 let disposedA=0;am[0].addEventListener('dispose',()=>disposedA++);
 a.meadow.setQuality('medium');
 check('same-look quality rebuild disposes old material once and retains A owner',()=>{assert.equal(disposedA,1);bound(materials(a),a,[10,20,30,40],0);});
 const B=look(),b=island(),prebuilt=materials(b);
 check('B prebuilt pool is unpatched before adoption',()=>{for(const m of prebuilt){assert.equal(m.uniforms.uTownRect,undefined);assert(!m.vertexShader.includes('float wbTownMask'));}});
 const bShell=b.meadow.shells[0],mesh=bShell.pool[0];mesh.material.uniforms.uCell.value.set(100,200,30,.3);
 let disposedB=0;prebuilt[0].addEventListener('dispose',()=>disposedB++);
 B.applyIsland(b);B.setTownGreenery([110,120,130,140],.75);
 const bm=materials(b);
 check('B prebuilt pool recreated once using independent B owner',()=>{assert.equal(disposedB,1);assert.notEqual(bm[0],prebuilt[0]);assert.notEqual(bm[0].uniforms.uTownRect,am[0].uniforms.uTownRect);bound(bm,b,[110,120,130,140],.75);});
 result.prebuiltUCellAfterReplacement=mesh.material.uniforms.uCell.value.toArray();
 A.setTownGreenery([-1,-2,1,2],.9);
 check('A setter leaves B rect and strength unchanged',()=>{bound(materials(a),a,[-1,-2,1,2],.9);bound(bm,b,[110,120,130,140],.75);});
 B.setTownGreenery([110,120,130,140],0);
 check('B disable leaves A unchanged',()=>{bound(bm,b,[110,120,130,140],0);bound(materials(a),a,[-1,-2,1,2],.9);});
 b.meadow.setQuality('medium');
 check('B quality rebuild remains owned by B',()=>bound(materials(b),b,[110,120,130,140],0));
 check('B lazy second grass cell uses B owner',()=>bound([b.meadow.shells[0].mesh(1).material],b,[110,120,130,140],0));
 const c=island(),cm=materials(c);
 check('unregistered third Meadow has exact upstream shader and no town uniforms',()=>{for(let i=0;i<2;i++){const s=c.meadow.shells.find(s=>s.kind===(i===0?'grass':'flower')),expected=original.call(s);try{assert.equal(cm[i].vertexShader,expected.vertexShader);assert.equal(cm[i].fragmentShader,expected.fragmentShader);assert.deepEqual(Object.keys(cm[i].uniforms),Object.keys(expected.uniforms));assert.equal(cm[i].uniforms.uTownRect,undefined);}finally{expected.dispose();}}});
 // Re-adopt an existing A meadow with B while supplying fresh non-meadow shader
 // holders. applyIsland is not a general idempotent whole-island repatch API.
 const adopted=island(),unused=adopted.meadow;
 for(const s of unused.shells)s.geo.dispose();
 adopted.meadow=a.meadow;
 const beforeAdopt=materials(a),oldAdoptGeo=a.meadow.shells[0].geo;let reAdoptDisposed=0;
 beforeAdopt.forEach(m=>m.addEventListener('dispose',()=>reAdoptDisposed++));
 B.applyIsland(adopted);B.setTownGreenery([210,220,230,240],.3);
 const afterAdopt=materials(adopted);
 check('re-adopt existing pool to B replaces materials and keeps geometry',()=>{assert.equal(reAdoptDisposed,2);assert.notEqual(afterAdopt[0],beforeAdopt[0]);assert.equal(adopted.meadow.shells[0].geo,oldAdoptGeo);assert.equal(adopted.meadow.wbTownUniforms.uTownRect,b.terrain.material.uniforms.uTownRect);bound(afterAdopt,b,[210,220,230,240],.3);});
 A.setTownGreenery([-10,-20,-5,-6],.1);
 check('old A setter no longer changes adopted pool',()=>bound(afterAdopt,b,[210,220,230,240],.3));
 adopted.meadow.setQuality('medium');
 check('re-adopted pool quality rebuild and lazy creation use new owner',()=>bound(materials(adopted),b,[210,220,230,240],.3));
 result.ok=true;
 result.limits=['The current single-init path and same-look quality rebuild are exercised at material-factory level, not full renderer execution.','Pool replacement still resets uCell; normal Meadow.update writes active cells before render. No direct render after hot replacement was tested.','Re-adoption test intentionally provides fresh non-meadow shader holders; calling applyIsland twice on already patched terrain is still outside its pre-existing non-idempotent contract.','No GPU compilation, resource-growth measurement, dispose reachability/GC proof or frame-time attribution.'];
}catch(e){result.ok=false;result.failure={name:e.name,message:e.message};throw e;}
finally{
 const meadows=new Set(islands.map(i=>i.meadow));for(const m of meadows)for(const s of m.shells){for(const mesh of s.pool)mesh.material.dispose();s.geo.dispose();}
 for(const i of islands)for(const k of ['terrain','transition','town','water'])i[k].material.dispose();
 for(const l of looks){l.pipeline.dispose();for(const k of ['blurMat','copyMat','downMat','upMat','raysMat','finalMat'])l.pipeline[k].dispose();}
 console.log(JSON.stringify(result,null,2));
}
