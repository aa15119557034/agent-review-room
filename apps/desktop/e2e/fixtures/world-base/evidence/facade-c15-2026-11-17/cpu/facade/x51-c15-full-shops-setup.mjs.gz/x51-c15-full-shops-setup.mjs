export async function buildFullShops(ctx, load, THREE) {
  // Canvas pixels/fonts mocked; real packing and complete shopsA geometry run.
  globalThis.document={createElement(tag){if(tag!=='canvas')throw Error('Unexpected element '+tag);const canvas={width:0,height:0};const g=new Proxy({canvas,measureText:s=>({width:String(s).length*8}),createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}}),createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4),width:w,height:h}),getImageData:(x,y,w,h)=>({data:new Uint8ClampedArray(w*h*4),width:w,height:h})},{get(t,k){return k in t?t[k]:()=>{};},set(t,k,v){t[k]=v;return true;}});canvas.getContext=()=>g;return canvas;}};
  const {createContext}=await load('/upstream/sakuragaoka/src/core/ctx.js');
  const support=createContext({scene:new THREE.Scene(),camera:new THREE.PerspectiveCamera(),sunDir:new THREE.Vector3(1,1,1).normalize(),quality:{}});
  ctx._cpuShopsSupport=support;
  for(const [key,value] of ctx.tex.cache)support.tex.cache.set(key,value);
  ctx.tex=support.tex;
  for(const key of ['geo','wires','addStatic','add','noBatch','quality','sunDir','onUpdate','player','camera','time'])ctx[key]=support[key];
  await (await load('/upstream/sakuragaoka/src/world/shopsA.js')).build(ctx);
}
