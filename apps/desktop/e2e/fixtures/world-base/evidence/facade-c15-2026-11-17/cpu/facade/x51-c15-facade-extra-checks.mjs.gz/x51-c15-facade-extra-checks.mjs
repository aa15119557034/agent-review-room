import fs from 'node:fs';
export function facadeChecks(THREE,city,ctx,source,base){
  city.root.updateWorldMatrix(true,true);
  const rootBox=new THREE.Box3().setFromObject(city.root), referencedMaterials=new Set(), borrowedTextures=new Set();
  city.root.traverse(o=>{if(o.isMesh)for(const m of Array.isArray(o.material)?o.material:[o.material]){referencedMaterials.add(m);for(const v of Object.values(m))if(v?.isTexture)borrowedTextures.add(v);}});
  const atlas=ctx.services.shopsA.buildContext.A.lit, page=atlas.pages[city.stats.laundrySignAtlas.page];
  const signMaterials=[...referencedMaterials].filter(m=>m.map===page.t);
  if(signMaterials.some(m=>m===page.m||m.clippingPlanes!==null))throw Error('Sign material is shared or clipped');
  const sharedMaterials=new Set(Object.values(source.M).filter(x=>x?.isMaterial)),sharedGeometries=new Set();
  ctx._cpuShopsSupport.scene.traverse(o=>{if(o.isMesh){sharedGeometries.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])sharedMaterials.add(m);}});
  for(const a of Object.values(ctx.services.shopsA.buildContext.A))for(const p of a.pages)sharedMaterials.add(p.m);
  const report=JSON.parse(fs.readFileSync(base+'/artifacts/gpu-look-c14-v1/look-report.json'));
  const views=report.captures.filter(c=>c.pass==='capture-2'&&['20-rear-eye','21-front-eye','laundry-details'].includes(c.view));
  const cameras=views.map(v=>{const c=new THREE.PerspectiveCamera(v.camera.fov,1.6,.1,5000);c.position.fromArray(v.camera.position);c.quaternion.fromArray(v.camera.quaternion);c.updateMatrixWorld(true);return {name:v.view,c};});
  const meshes=[];city.root.traverse(o=>{if(o.isMesh && !o.material.transparent)meshes.push(o);});
  const rays=[],ray=new THREE.Raycaster();
  for(const b of city.stats.facadeLife.buildings)for(const item of b.items){if(item.kind!=='ac')continue;const pos=new THREE.Vector3(...item.position).add(new THREE.Vector3(...b.origin)).add(city.root.position);pos.y+=.38;if(item.face==='west')pos.x-=.14;else pos.z-=.14;const projections=cameras.map(({name,c})=>{const ndc=pos.clone().project(c),distance=pos.distanceTo(c.position);ray.set(c.position,pos.clone().sub(c.position).normalize());const hits=ray.intersectObjects(meshes,false);return {view:name,ndc:ndc.toArray(),inFrustum:Math.abs(ndc.x)<=1&&Math.abs(ndc.y)<=1&&Math.abs(ndc.z)<=1,rayDistance:distance,firstHit:hits[0]?{distance:hits[0].distance,name:hits[0].object.name}:null,nearTarget:!!hits[0]&&Math.abs(hits[0].distance-distance)<.08};});rays.push({building:b.name,item,worldFanPoint:pos.toArray(),projections});}
  const disposed={materials:[],geometries:[],textures:[]},original={m:THREE.Material.prototype.dispose,g:THREE.BufferGeometry.prototype.dispose,t:THREE.Texture.prototype.dispose};
  THREE.Material.prototype.dispose=function(){disposed.materials.push({uuid:this.uuid,shared:sharedMaterials.has(this)});return original.m.call(this);};
  THREE.BufferGeometry.prototype.dispose=function(){disposed.geometries.push({uuid:this.uuid,shared:sharedGeometries.has(this)});return original.g.call(this);};
  THREE.Texture.prototype.dispose=function(){disposed.textures.push(this.uuid);return original.t.call(this);};
  return {finish(){THREE.Material.prototype.dispose=original.m;THREE.BufferGeometry.prototype.dispose=original.g;THREE.Texture.prototype.dispose=original.t;if(disposed.textures.length||disposed.materials.some(m=>m.shared)||disposed.geometries.some(g=>g.shared))throw Error('City released shared resources');return {scope:'CPU actual geometry raycasts; excludes transparent meshes but does not evaluate alpha/shaders or pixels. Fixed C14 camera. Not GPU visibility proof.',rootBounds:{min:rootBox.min.toArray(),max:rootBox.max.toArray()},signMaterials:{count:signMaterials.length,allCloned:signMaterials.every(m=>m!==page.m),allUnclipped:signMaterials.every(m=>m.clippingPlanes===null),textureBorrowed:true},acProjections:rays,disposals:{materialCalls:disposed.materials.length,uniqueMaterials:new Set(disposed.materials.map(m=>m.uuid)).size,geometryCalls:disposed.geometries.length,uniqueGeometries:new Set(disposed.geometries.map(g=>g.uuid)).size,textureCalls:disposed.textures.length,sharedMaterialCalls:disposed.materials.filter(m=>m.shared).length,sharedGeometryCalls:disposed.geometries.filter(g=>g.shared).length}};}};
}
