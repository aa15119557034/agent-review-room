# W3 樱花与站区建筑的来源和许可

本包在 2026-11-18 首版 Blender 素材的 `mature-sakura.glb` 上改作，输入 SHA-256 为 `767abe15569aad1b12f9b9b80201c4bab49251aaf3077dab02dab3320ad9f2aa`。两棵树来自 MIT 的 Sakuragaoka Station，固定版本为 `4112f57208b7e29998344ca71fef74202c2b2bdd`，项目适配为 `9cfe2de5e4199502a20f1c569fc1cee86abc2649`。W3 树冠沿用这棵树的枝端约束，新建实体花团、分叉枝梢与带瓣尖凹口的五瓣花。三个已有贴图继续随 GLB 内嵌。广场树三部分、W3 树干、种植和碰撞元数据沿用首版。[上游源码](https://github.com/kiarashfa/sakuragaoka/tree/4112f57208b7e29998344ca71fef74202c2b2bdd) · [项目适配](https://github.com/aa15119557034/agent-review-room/commit/9cfe2de5e4199502a20f1c569fc1cee86abc2649)

首版的三栋楼为本地 Blender 原创建模。本版在洗衣店左翼上一道竖缝里增加一条浅背衬，沿用既有的烘焙顶点色与材质。运行包也包含首版后巷工房和东侧退台楼，二者可按原 SHA 校验。

模型、改作与构建脚本按所附 MIT 许可提供。再分发时请附上 [Sakuragaoka 的许可](licenses/LICENSE-Sakuragaoka.txt) 和 [本地改作的许可](licenses/LICENSE-station-art.txt)。预览中其余场景资产沿用 fixture 的来源说明。西侧办公楼使用主窗口准备的 Kenney CC0 候选。[Kenney 原包](https://kenney.nl/assets/city-kit-commercial)
