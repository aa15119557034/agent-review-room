import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {registerHooks} from 'node:module';
const fixture=pathToFileURL(path.resolve(process.argv[2])+'/');
const vendor=new URL('upstream/petalwake/vendor/three/',fixture);
registerHooks({resolve(s,c,next){if(s==='three')return {url:new URL('build/three.module.js',vendor).href,shortCircuit:true};if(s.startsWith('three/addons/'))return {url:new URL('examples/jsm/'+s.slice(13),vendor).href,shortCircuit:true};return next(s,c)}});
const T=await import('three');
const core=n=>import(new URL('upstream/sakuragaoka/src/'+n+'.js',fixture)),L=await core('world/layout');
const {mulberry32}=await core('core/ctx'),{createNoise}=await core('world/sakura/util'),{makePlacements}=await core('world/sakura/placements'),{makeTree}=await core('world/sakura/tree');
const inp=fs.readFileSync(process.argv[4]),jl=inp.readUInt32LE(12),doc=JSON.parse(inp.subarray(20,20+jl)),off=28+jl;
function attribute(idx){const a=doc.accessors[idx],b=doc.bufferViews[a.bufferView],offset=off+(b.byteOffset||0)+(a.byteOffset||0),n={SCALAR:1,VEC2:2,VEC3:3,VEC4:4}[a.type],dt={5123:Uint16Array,5125:Uint32Array,5126:Float32Array,5121:Uint8Array}[a.componentType];if(b.byteStride)throw Error('unexpected interleaved accessor');return new dt(inp.buffer,inp.byteOffset+offset,a.count*n)}
const makeV=(p,i,base)=>new T.Vector3(p[i*3]+base[0],p[i*3+1]+base[1],p[i*3+2]+base[2]);
const env={rng:mulberry32,noise:createNoise(mulberry32('sakura-noise')),heightAt:L.heightAt};
const placements=makePlacements({L,rng:mulberry32,services:{houses:{}}}).trees;
const results={};
for(const spec of placements.filter(s=>s.kind==='old')){
 const orig=makeTree(spec,env),offset=[spec.x,orig.groundY,spec.z],boxes=spec.keepOut.map(b=>new T.Box3(new T.Vector3(b.x0,b.y0,b.z0),new T.Vector3(b.x1,b.y1,b.z1)));
 const score=(p,idx,base)=>{
  const cs=boxes.map(()=>0);let minFloor=Infinity,degenerate=0;
  const vertices=[];for(let i=0;i<p.length/3;i++){const v=makeV(p,i,base);if(!Number.isFinite(v.x+v.y+v.z))throw Error('non-finite vertex');vertices.push(v)}
  const point=new T.Vector3(),tri=new T.Triangle();
  for(let i=0;i<idx.length;i+=3){
    const [a,b,c]=[vertices[idx[i]],vertices[idx[i+1]],vertices[idx[i+2]]];tri.set(a,b,c);if(tri.getArea()<5e-10)degenerate++;
    boxes.forEach((box,j)=>{if(box.intersectsTriangle(tri))cs[j]++});
    for(const q of [a,b,c])minFloor=Math.min(minFloor,q.y-spec.floorAt(q.x,q.z));
    for(const [x,y] of [[a,b],[b,c],[c,a]]){point.addVectors(x,y).multiplyScalar(.5);minFloor=Math.min(minFloor,point.y-spec.floorAt(point.x,point.z))}
    tri.getMidpoint(point);minFloor=Math.min(minFloor,point.y-spec.floorAt(point.x,point.z));
  }
  return{triangles:idx.length/3,degenerate,boxIntersections:cs,minVsFloorSampleMetres:+minFloor.toFixed(5)};
 };
 const rows={};for(const role of ['bark','blob','cards']){
  const pr=doc.meshes.find(m=>m.name===spec.id+'-'+role).primitives[0];
  rows[role]={original:score(orig[role].p,orig[role].i,[0,0,0]),baked:score(attribute(pr.attributes.POSITION),attribute(pr.indices),offset)};
 }
 results[spec.id]={boxLabels:spec.id==='w3'?['W3-house','W2-florist','W4-bookshop']:['station'],roles:rows};
}
fs.writeFileSync(process.argv[3],JSON.stringify({scope:'Full triangle vs each placement keepOut AABB. Minimum versus floorAt uses vertices, three edge midpoints, and barycentre. Bark includes the stem and roots and is expected below canopy floor.',results},null,2)+'\n');console.log(JSON.stringify(results));
