"""Export editable scenes, validate the two mature trees, and produce the four runtime GLBs."""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
args=argparse.ArgumentParser(description=__doc__)
args.add_argument('--fixture',required=True,type=Path,help='Existing world-base fixture checkout with its tracked Three.js')
args.add_argument('--blender',default='blender',help='Blender 5.2.2 executable name or absolute path')
args.add_argument('--node',default='node',help='Node.js 24.7+ executable name or absolute path')
args.add_argument('--out',required=True,type=Path,help='Separate empty destination directory')
args.add_argument('--scenes',type=Path,default=root,help='Editable scene root, including the output of regenerate.py')
args.add_argument('--verify',action='store_true',help='Require byte-for-byte identity with the recorded four runtime files')
opts=args.parse_args()
out=opts.out.resolve()
if out==root or root in out.parents:raise SystemExit('Choose an output directory outside the source pack')
out.mkdir(parents=True,exist_ok=True)
if any(out.iterdir()):raise SystemExit(f'Output directory must be empty: {out}')
fixture=opts.fixture.resolve()
if not (fixture/'upstream/sakuragaoka/src/world/sakura/tree.js').is_file():raise SystemExit(f'Invalid fixture: {fixture}')
work=out/'build'
work.mkdir()
subprocess.run([opts.blender,'--background','--factory-startup','--threads','2','--python-exit-code','1',
                '--python',str(root/'scripts/export_editable.py'),'--',str(opts.scenes.resolve()),str(work)],check=True)
subprocess.run([sys.executable,str(root/'scripts/assemble.py'),'--base',str(work/'mature-base.glb'),'--parts',str(work/'w3-parts.glb'),
                '--tree','w3','--out',str(work/'mature-w3.glb'),'--report',str(work/'w3-assembly.json')],check=True)
subprocess.run([sys.executable,str(root/'plaza-blossom/scripts/assemble.py'),'--base',str(work/'mature-w3.glb'),
                '--parts',str(work/'plaza-parts.glb'),'--atlas',str(opts.scenes.resolve()/'plaza-blossom/source/plaza-sprays.png'),
                '--output',str(work/'mature-sakura.glb'),'--report',str(work/'plaza-assembly.json')],check=True)
subprocess.run([opts.node,str(root/'scripts/clearance.mjs'),str(fixture),str(work/'clearance.json'),str(work/'mature-sakura.glb')],check=True)
clear=json.loads((work/'clearance.json').read_text(encoding='utf-8'))
for tree,info in clear['results'].items():
    for role,value in info['roles'].items():
        data=value['baked']
        if data['degenerate'] or any(data['boxIntersections']) or (role!='bark' and data['minVsFloorSampleMetres']<=0):
            raise RuntimeError(f'{tree} {role}: {data}')
expected=json.loads((root/'expected-assets.json').read_text(encoding='utf-8'))
actual={name:hashlib.sha256((work/name).read_bytes()).hexdigest() for name in expected}
if opts.verify and actual!=expected:raise RuntimeError(f'Runtime hash mismatch: {actual}')
target=out/'export'
target.mkdir()
for name in actual:shutil.copyfile(work/name,target/name)
if opts.verify:
    subprocess.run([sys.executable,str(root/'scripts/package_runtime.py'),str(target),str(out/'station-art-fixture.zip')],check=True)
(out/'sha256.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf-8')
print(json.dumps(actual,indent=2))

