"""Regenerate the four editable .blend files from the included Blender recipes and original seed."""
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--blender',default='blender')
ap.add_argument('--fixture',required=True,type=Path)
ap.add_argument('--node',default='node')
ap.add_argument('--out',required=True,type=Path,help='Separate empty working directory')
cfg=ap.parse_args()
work=cfg.out.resolve()
if work==root or root in work.parents:raise SystemExit('Use an output directory outside the source pack')
work.mkdir(exist_ok=True,parents=True)
if any(work.iterdir()):raise SystemExit('Recipe output directory must be empty')
for name in ('station-art','w3-blossom-edge','plaza-blossom'):
    (work/name/'source').mkdir(parents=True)
    (work/name/'export').mkdir()
    (work/name/'checks').mkdir()
    shutil.copytree(root/name/'scripts',work/name/'scripts')
shutil.copytree(root/'station-art/paint',work/'station-art/paint')
for item in ('station-art/source/blossom-anchors.json','w3-blossom-edge/source/w3-floor.json'):
    shutil.copyfile(root/item,work/item)
def run(script,*arguments):
    cli=[cfg.blender,'--background','--factory-startup','--threads','2','--python-exit-code','1','--python',str(work/script)]
    if arguments:cli+=['--',*map(str,arguments)]
    subprocess.run(cli,check=True)

run('station-art/scripts/build_buildings.py')
run('station-art/scripts/build_trees.py',root/'inputs/mature-sakura-seed.glb')
run('w3-blossom-edge/scripts/build.py')
run('w3-blossom-edge/scripts/build_portal.py')
subprocess.run([cfg.node,str(work/'plaza-blossom/scripts/survey.mjs'),str(cfg.fixture.resolve())],check=True)
subprocess.run([sys.executable,str(work/'plaza-blossom/scripts/paint_sprays.py')],check=True)
for name in ('branch-survey.json','plaza-sprays.png'):
    path=Path('plaza-blossom/source')/name
    if (work/path).read_bytes()!=(root/path).read_bytes():
        raise ValueError('Regenerated survey/paint differs from the reviewed source: '+name)
run('plaza-blossom/scripts/build.py')
print('Editable files regenerated under',work)

