"""Splice two editable crown primitives, preserving every other buffer and all collision metadata."""
from pathlib import Path
import argparse, copy, hashlib, json, struct
import numpy as np
parser=argparse.ArgumentParser()
parser.add_argument('--base',type=Path,required=True)
parser.add_argument('--parts',type=Path,required=True)
parser.add_argument('--tree',choices=['w3','plaza'],required=True)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--report',type=Path,required=True)
opts=parser.parse_args()
src,parts,prefix,output,report_path=opts.base,opts.parts,opts.tree,opts.out,opts.report
sha=lambda data:hashlib.sha256(data).hexdigest()
class GLB:
    def __init__(self,path):
        data=path.read_bytes();n=struct.unpack_from('<I',data,12)[0]
        self.d=json.loads(data[20:20+n]);self.bin=data[28+n:]
    def view(self,i):
        v=self.d['bufferViews'][i];a=v.get('byteOffset',0);return self.bin[a:a+v['byteLength']]
    def prim(self,name):
        ps=next(m for m in self.d['meshes'] if m['name']==name)['primitives'];assert len(ps)==1;return ps[0]
    def roles(self,name):
        p=self.prim(name);return {**p['attributes'],'indices':p['indices']}
    def base_color_image(self,name):
        material=self.d['materials'][self.prim(name)['material']]
        tex=material['pbrMetallicRoughness']['baseColorTexture']['index']
        image=self.d['images'][self.d['textures'][tex]['source']]
        return self.view(image['bufferView'])
    def payload(self,name):
        return {k:sha(self.view(self.d['accessors'][i]['bufferView'])) for k,i in self.roles(name).items()}
a=GLB(src);b=GLB(parts);d=copy.deepcopy(a.d)
views=[a.view(i) for i in range(len(d['bufferViews']))]
targets=[prefix+'-blob',prefix+'-cards']
for name in targets:
    if a.base_color_image(name)!=b.base_color_image(name):
        raise ValueError(name+' uses a new texture. Include its independent material, texture and image in the revised assembly.')
    old,new=a.roles(name),b.roles(name)
    assert set(old)==set(new)
    for key,oi in old.items():
        ni=new[key];nb=b.d['accessors'][ni]['bufferView'];ob=d['accessors'][oi]['bufferView']
        d['accessors'][oi]={**b.d['accessors'][ni],'bufferView':ob}
        views[ob]=b.view(nb);d['bufferViews'][ob]={**b.d['bufferViews'][nb],'buffer':0}
out=bytearray()
for view,data in zip(d['bufferViews'],views):
    out+=bytes((-len(out))%4);view['byteOffset']=len(out);view['byteLength']=len(data);out+=data
d['buffers'][0]['byteLength']=len(out);out+=bytes((-len(out))%4)
head=json.dumps(d,separators=(',',':')).encode();head+=b' '*(-len(head)%4)
dst=output
dst.write_bytes(struct.pack('<4sII',b'glTF',2,28+len(head)+len(out))+struct.pack('<I4s',len(head),b'JSON')+head+struct.pack('<I4s',len(out),b'BIN\x00')+out)
g=GLB(dst);unchanged={}
for m in d['meshes']:
    name=m['name']
    if name not in targets:
        assert g.payload(name)==a.payload(name);unchanged[name]=g.payload(name)
for key in ['nodes','meshes','materials','images','textures','samplers','scenes']:assert d[key]==a.d[key]
for im in d['images']:assert a.view(im['bufferView'])==g.view(im['bufferView'])
report={'sha256':sha(dst.read_bytes()),'bytes':dst.stat().st_size,'baseSha256':sha(src.read_bytes()),'unchangedMeshes':unchanged,
        'nodesMaterialsAndTexturesMatch':True,'materials':len(d['materials']),'meshes':{}}
for m in d['meshes']:
    name=m['name'];attrs=g.roles(name)
    def array(key,lanes):
        ac=d['accessors'][attrs[key]];v=d['bufferViews'][ac['bufferView']]
        typ=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[ac['componentType']])
        return np.ndarray((ac['count'],lanes),dtype=typ,buffer=g.view(ac['bufferView']),offset=ac.get('byteOffset',0),strides=(v.get('byteStride',lanes*typ.itemsize),typ.itemsize))
    idx=array('indices',1).reshape(-1,3);p=array('POSITION',3)
    assert np.isfinite(p).all() and idx.max()<len(p)
    p0,p1,p2=(p[i] for i in idx.T);area=np.linalg.norm(np.cross(p1-p0,p2-p0),axis=1)/2
    report['meshes'][name]={'triangles':len(idx),'degenerate':int((area<5e-10).sum())}
report['triangles']=sum(v['triangles'] for v in report['meshes'].values())
report_path.write_text(json.dumps(report,indent=2)+'\n')
print(report['bytes'],report['sha256'],report['meshes'])
assert all(m['degenerate']==0 for m in report['meshes'].values())
