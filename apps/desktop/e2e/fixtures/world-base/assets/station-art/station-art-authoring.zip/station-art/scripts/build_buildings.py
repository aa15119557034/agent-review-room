"""Author two metre-scale building kits. Arguments/coordinates here use glTF Y up,
with +Z out of the front; conversion happens only when committing the mesh."""
import bpy
import math
from pathlib import Path
from mathutils import Vector

root=Path(__file__).resolve().parents[1]
for folder in ['source','export']: (root/folder).mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0

def linear(h):
    c=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return [v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in c]+[1]

class Assembly:
    def __init__(self, name, parent, material):
        self.name,self.parent,self.mat=name,parent,material
        self.v=[];self.f=[];self.paint=[]
    def solid(self,points,faces,colour):
        base=len(self.v)
        self.v.extend((x,-z,y) for x,y,z in points)
        self.f.extend([tuple(base+i for i in face) for face in faces])
        self.paint.extend([colour]*len(faces))
    def box(self,x0,x1,y0,y1,z0,z1,c):
        assert x1>x0 and y1>y0 and z1>z0
        self.ramp(x0,x1,y0,z0,z1,y1,y1,c)
    def ramp(self,x0,x1,bottom,z0,z1,back,front,c):
        p=[(x0,bottom,z0),(x1,bottom,z0),(x1,bottom,z1),(x0,bottom,z1),
           (x0,back,z0),(x1,back,z0),(x1,front,z1),(x0,front,z1)]
        self.solid(p,[(0,1,2,3),(4,7,6,5),(0,4,5,1),(2,6,7,3),(0,3,7,4),(1,5,6,2)],c)
    def cylinder(self,x,z,y0,y1,r,c,n=10):
        p=[(x+math.cos(k*math.tau/n)*r,y,z+math.sin(k*math.tau/n)*r) for y in (y0,y1) for k in range(n)]
        faces=[tuple(range(n)),tuple(reversed(range(n,n*2)))]
        for i in range(n):
            j=(i+1)%n;faces.append((i,i+n,j+n,j))
        self.solid(p,faces,c)
    def finish(self):
        mesh=bpy.data.meshes.new(self.name);mesh.from_pydata(self.v,[],self.f);mesh.update()
        ob=bpy.data.objects.new(self.name,mesh);bpy.context.collection.objects.link(ob)
        ob.parent=self.parent;mesh.materials.append(self.mat)
        colours=mesh.color_attributes.new(name='Enamel',type='BYTE_COLOR',domain='CORNER')
        for face,h in zip(mesh.polygons,self.paint):
            for i in face.loop_indices: colours.data[i].color=linear(h)
        return ob

def group(name):
    ob=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(ob)
    return ob

def paint(name):
    m=bpy.data.materials.new(name);m.use_nodes=True
    vert=m.node_tree.nodes.new('ShaderNodeVertexColor');vert.layer_name='Enamel'
    bs=m.node_tree.nodes.get('Principled BSDF')
    m.node_tree.links.new(vert.outputs['Color'],bs.inputs['Base Color'])
    bs.inputs['Roughness'].default_value=.93
    bs.inputs['Specular IOR Level'].default_value=.16
    m.use_backface_culling=True
    return m

workshop=group('Alley workshop')
body=Assembly('Workshop',workshop,paint('Workshop | baked paint'))
b=body.box
wall='b5c3b9'; trim='c3c7b5'; roof='647e82'; edge='41585e'; glass='709597'
# Inset loading shutter and pedestrian door in genuine front recesses.
b(-2.68,2.68,0,.16,-3.03,3.03,'858781')
b(-2.62,-2.43,.16,3.05,-2.98,2.97,wall); b(2.43,2.62,.16,3.05,-2.98,2.97,wall)
b(-2.43,2.43,.16,3.05,-2.98,-2.78,wall)
for lo,hi in [(-2.43,-2.14),(.61,.97),(1.96,2.43)]:b(lo,hi,.16,3.05,2.76,2.97,wall)
b(-2.14,.61,2.52,3.05,2.76,2.97,wall);b(.97,1.96,2.24,3.05,2.76,2.97,wall)
b(-2.14,.61,.16,2.52,2.67,2.75,'778b8b')
for i in range(8):
    y=.25+i*.265;b(-2.12,.59,y,y+.025,2.75,2.78,'647d80')
b(-2.16,.63,2.5,2.70,2.79,3.05,edge)
b(.97,1.96,.16,2.24,2.64,2.73,'687d79')
b(1.10,1.83,1.03,2.08,2.735,2.75,'a1bab7')
b(1.12,1.16,.86,1.07,2.75,2.80,'d8ceba')
# North-light roof with two raised glazed faces. The peak spacing is intentionally asymmetric.
for z0,z1,low,high in [(-3.12,-.58,3.11,3.88),(-.58,3.04,3.13,4.38)]:
    body.ramp(-2.67,2.67,3.0,z0,z1,low,high,roof)
    body.ramp(-2.74,2.74,high-.09,z1-.09,z1+.09,high+.02,high+.04,edge)
    b(-2.48,2.48,3.17,high-.11,z1,z1+.028,'536b71')
    for j in range(5):
        x=-2.40+j*.97
        b(x,x+.89,3.22,high-.17,z1+.029,z1+.046,glass if j%3 else '92aaa9')
    for j in range(1,6):
        x=-2.66+j*.89
        body.ramp(x-.016,x+.016,3.03,z0,z1,low+.022,high+.022,'879b9a')
# Angled metal rain hood, wall bases and downpipes catch a broad strip of dusk light.
body.ramp(-2.31,.80,2.72,2.89,3.62,2.96,2.80,'869d97')
b(-2.35,.84,2.70,2.80,3.60,3.64,edge)
for x in [-2.51,2.51]:body.cylinder(x,3.035,.17,3.2,.053,edge,8)
b(-2.62,-2.58,.16,.64,-2.91,2.82,'718984')
b(2.58,2.65,.16,.64,-2.91,2.82,'718984')
# Flue offset to one end, with collar, cap and rectangular service chase.
b(1.72,2.14,3.33,3.68,-1.78,-1.34,'52666a')
body.cylinder(1.93,-1.56,3.48,4.63,.15,'929d96',12)
body.cylinder(1.93,-1.56,4.61,4.74,.22,edge,12)
b(.69,.92,1.48,1.78,2.97,2.992,'b18d65')
# Deep set bank of side windows reads from an oblique approach.
for x0,x1 in [(-2.65,-2.621),(2.621,2.65)]:
    for z in [-1.90,-.40,1.10]:
        b(x0,x1,1.25,2.38,z-.02,z+1.15,edge)
        b(x0-.009,x1+.009,1.37,2.29,z+.06,z+1.07,'8da8a7')
        b(x0-.019,x1+.019,1.24,1.32,z-.07,z+1.2,'c6c8b3')
body.finish()

laundry=group('Laundry infill')
mat=paint('Infill | baked ceramic and metal')
wings=Assembly('Portal_wings',laundry,mat); b=wings.box
# Fabricated as same-depth replacement wings. Highest decorated face is at 6 mm,
# leaving the site's existing 12 mm-offset posters visible.
for sign in [-1,1]:
    left,right=(-6,-3) if sign==-1 else (3,6)
    b(left,right,.16,2.85,-.26,-.018,'8f9d9b')
    # Warm ivory above a muted celadon tile base. Large sheet seams survive dusk.
    for lo,hi,c in [(.16,.27,'647a77'),(.28,.54,'90a8a0'),(.55,.80,'9cb4aa'),(.812,.86,'708f88'),(.87,2.82,'c9c7b4')]:
        for j in range(3):
            x=left+j*(right-left)/3
            b(x+.004,x+.996,lo,hi,-.018,.003 if lo<.87 else 0,c)
    b(left,right,2.82,2.85,-.018,.004,'899794')
    # Recessed joint at the shop's outer return, clear of the notice cluster.
    outer=left+.12 if sign==-1 else right-.16
    b(outer,outer+.035,.27,2.82,0,.006,'8c9b95')
b(-3,3,2.36,2.85,-.26,0,'b3b8aa')
wings.finish()
# Independently selectable carcass for a new plot, with a roof, return walls,
# rear service elevation and two layers of glazing inside a six-metre portal.
shell=Assembly('Shell',laundry,mat);b=shell.box
b(-6,6,0,.16,-5.9,0,'87928d')
b(-6,-5.82,.16,2.85,-5.9,-.26,'c8c7b6')
b(5.82,6,.16,2.85,-5.9,-.26,'bbc2b4')
b(-5.82,5.82,.16,2.85,-5.90,-5.72,'b6beb1')
b(-6.09,6.09,2.85,3.02,-5.97,.12,'6e8280')
b(-6,6,3.02,3.20,-.06,.06,'c2c8b8')
for x in [-5.93,5.93]:b(x-.07,x+.07,3.02,3.20,-5.90,-.06,'adb8ae')
b(-6,6,3.02,3.20,-5.90,-5.76,'a9b4ae')
for x in [-4.6,-2.8,1.7,3.5]:
    b(x,x+1.27,1.03,2.29,-5.93,-5.9,'708786')
    b(x+.06,x+1.21,1.10,2.22,-5.94,-5.93,'9eb5af')
b(-.55,.55,.16,2.24,-5.93,-5.90,'677c78')
shell.finish()
front=Assembly('Front_cassette',laundry,mat);b=front.box
for x0,x1 in [(-3,-.62),(-.57,.57),(.62,3)]:
    b(x0,x1,.16,2.36,-.22,-.18,'738a89')
    b(x0+.055,x1-.055,.26,2.26,-.18,-.15,'a7bdb5')
    b(x0,x1,.66,.72,-.15,-.13,'718d86')
b(.36,.39,.95,1.27,-.13,-.07,'777c71')
b(-3.13,3.13,2.40,2.63,-.12,.55,'688a83')
b(-3.13,3.13,2.40,2.47,.55,.58,'bbad8c')
front.finish()

exchange=group('Station exchange')
t=Assembly('Stepped_exchange',exchange,paint('Exchange | baked facade bands')); b=t.box
# Compact eastern street-end lot. Its rounded tank and asymmetric shoulder
# contrast with the rectangular Kenney tower in the opposite window.
b(-3.03,3.03,0,.32,-3.49,3.49,'808b89')
b(-2.99,2.99,.32,13.22,-3.45,3.45,'abb7b5')
b(-2.99,1.64,13.22,16.31,-3.45,2.86,'bcc4bd')
b(1.64,2.99,13.22,13.44,-3.45,3.45,'697c80')
b(-3.09,1.74,16.31,16.54,-3.52,2.97,'778b8c')
# A stair tower climbs the blind side, breaking the slab's silhouette above the roof.
b(-3.06,-1.79,0,17.35,-2.16,1.22,'8c9c9d')
b(-3.15,-1.70,17.35,17.52,-2.21,1.27,'6b7b80')
for floor in range(5):
    y=.68+floor*3.16; upper=(floor==4); z=2.86 if upper else 3.45
    xhi=1.42 if upper else 2.74
    b(-2.74,xhi,y+.85,y+2.24,z,z+.03,'637c85')
    for i in range(3 if upper else 4):
        x=-2.66+i*1.34
        b(x,x+1.23,y+.94,y+2.16,z+.03,z+.052,'89a4a7' if i%3 else 'a1b4b0')
    b(-2.82,xhi+.08,y+.77,y+.88,z-.01,z+.12,'c0c4b7')
    for zz in [-2.59,-.86,.87]:
        xx=1.64 if upper else 2.99
        b(xx,xx+.045,y+1.04,y+2.17,zz,zz+1.32,'81989c')
    b(-3.08,-3.058,y+1.43,y+2.01,-1.82,.83,'6f8387')
# Set-back, elevated banded cistern. The gaps under it stay open.
for x in [-.91,.94]:
    for z in [-1.30,.52]:
        b(x-.095,x+.095,16.54,17.93,z-.095,z+.095,'596e74')
b(-1.26,1.26,17.87,18.11,-1.7,.86,'62777b')
t.cylinder(0,-.42,18.11,20.18,1.22,'99a8a5',20)
for y in [18.13,19.12,20.09]:t.cylinder(0,-.42,y,y+.085,1.26,'6b7e81',20)
t.cylinder(0,-.42,20.17,20.31,1.12,'c1c5b5',20)
t.cylinder(.12,-.44,20.31,20.54,.22,'72858a',12)
b(-1.30,.26,.32,2.38,3.45,3.50,'52696e')
b(-1.22,.18,.39,2.30,3.50,3.52,'839f9c')
b(-1.52,.51,2.39,2.56,3.45,3.91,'7d9392')
t.finish()

def export(g,filename):
    bpy.ops.object.select_all(action='DESELECT')
    for ob in [g,*g.children]: ob.select_set(True)
    bpy.context.view_layer.objects.active=g
    bpy.ops.export_scene.gltf(filepath=str(root/'export'/filename),export_format='GLB',use_selection=True,
        export_yup=True,export_vertex_color='ACTIVE',export_animations=False,export_lights=False,export_cameras=False)
export(workshop,'alley-workshop.glb');export(laundry,'laundry-infill.glb');export(exchange,'station-exchange.glb')
workshop.location.x=-8;laundry.location.x=5;exchange.location.x=18
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_distance=49
        area.spaces.active.region_3d.view_location=(4,0,7)
        area.spaces.active.shading.color_type='VERTEX'
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.wm.save_as_mainfile(filepath=str(root/'source/station-buildings.blend'),compress=True)
