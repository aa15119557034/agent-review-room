"""Build the two GLB variants in their exact 9cfe2de loader contract."""
import bpy
import bmesh
import hashlib
import json
import math
import random
import sys
import struct
from pathlib import Path
from mathutils import Vector

root=Path(__file__).resolve().parents[1]
source=Path(sys.argv[-1])
assert hashlib.sha256(source.read_bytes()).hexdigest()=='d0a8a72a3da09946007d52b79ca2d30682654d5a7edca51f9909c0259894437e'
for name in ['export','source']: (root/name).mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.import_scene.gltf(filepath=str(source))

def tint(code):
    a=[int(code[i:i+2],16)/255 for i in (0,2,4)]
    return Vector([x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in a])

def swap_map(mat, filename):
    image=bpy.data.images.load(str(root/'paint'/filename))
    image.pack()
    for n in mat.node_tree.nodes:
        if n.type=='TEX_IMAGE': n.image=image

def tiers(ob,pads):
    # Separate, overlapping blossom clusters at the ends of the actual woody
    # branches. Large colour masses survive minification without noisy alpha.
    vertices=[]; faces=[]; colours=[]; normals=[]; uvs=[]
    sides=12
    for pad in pads:
        ctr=Vector(pad['center']);rx,ry,h=pad['radii'];seed=pad['seed']
        phase=seed*.77
        angle=seed*1.73
        ca,sa=math.cos(angle),math.sin(angle)
        palette=['d58ca5','e89bb1','ffc1cc','ffdbd9','ffdfd5']
        if pad['peach']>.3:palette=['ce8c9d','e89fa9','ffbdbe','ffd4c6','ffdccf']
        def point(sx,sy,sz,fleck):
            # Rotate only the irregular plan, leaving its surveyed X/Y extents bounded.
            xx,yy=ca*sx-sa*sy,sa*sx+ca*sy
            vertices.append(tuple(ctr+Vector((rx*xx,ry*yy,h*sz))))
            n=Vector((xx*.73,yy*.73,sz*1.36)).normalized()
            normals.append(tuple(n))
            score=.68*sz-.17*xx-.11*yy+.15*math.sin(seed)+fleck
            bands=[-.67,-.27,.03,.40,.76]
            color=tint(palette[0])
            for k in range(1,len(bands)):
                f=max(0,min(1,(score-bands[k]+.09)/.18))
                color=color.lerp(tint(palette[k]),f)
            colours.append((*color,1))
            uvs.append((xx*.59+seed*.37+sz*.29,yy*.59+seed*.73+sz*.43))
            return len(vertices)-1
        bottom=point(.08,-.045,-1.08,0)
        rings=[]
        for tier,(rad,height) in enumerate([(.72,-.75),(1.0,-.06),(.78,.69)]):
            ring=[]
            for k in range(sides):
                a=math.tau*(k+(tier-1)*.19)/sides+phase
                scallop=.95+.075*math.cos(3*a+phase)+.065*math.sin(5*a+seed)
                droop=.13*math.cos(3*a+phase)+.08*math.sin(2*a+.48*seed)
                ring.append(point(rad*scallop*math.cos(a),rad*scallop*math.sin(a),height+droop,.055*math.cos(a*2+phase)))
            rings.append(ring)
        top=point(-.17,.08,1.12,0)
        for k in range(sides):
            j=(k+1)%sides
            faces.append((bottom,rings[0][j],rings[0][k]))
            for lo,hi in zip(rings,rings[1:]):faces.append((lo[k],lo[j],hi[j],hi[k]))
            faces.append((rings[-1][k],rings[-1][j],top))
    old=ob.data;mat=old.materials[0]
    mesh=bpy.data.meshes.new('Branch blooms');mesh.from_pydata(vertices,[],faces);mesh.materials.append(mat);mesh.update()
    ob.data=mesh;bpy.data.meshes.remove(old);mesh.name=ob.name
    col=mesh.color_attributes.new(name='Color',type='BYTE_COLOR',domain='POINT')
    for i,value in enumerate(colours): col.data[i].color=value
    uv=mesh.uv_layers.new(name='Glaze')
    for lo in mesh.loops: uv.data[lo.index].uv=uvs[lo.vertex_index]
    for face in mesh.polygons:face.use_smooth=True
    mesh.normals_split_custom_set_from_vertices(normals)

def reduce_sprays(ob):
    # glTF input stores four separate vertices per sprig and two adjacent
    # triangles. Keep complete sprigs so the clipped edges retain their UVs.
    bm=bmesh.new();bm.from_mesh(ob.data);bm.faces.ensure_lookup_table()
    faces=list(bm.faces);assert len(faces)%2==0
    rng=random.Random(173 if ob.parent.name=='w3' else 211)
    remove=[]
    for i in range(0,len(faces),2):
        a,b=faces[i:i+2];assert len(set(a.verts)|set(b.verts))==4
        if rng.random()>.38:remove.extend([a,b])
    bmesh.ops.delete(bm,geom=remove,context='FACES')
    bm.to_mesh(ob.data);bm.free();ob.data.update()

anchors=json.loads((root/'source/blossom-anchors.json').read_text())
for variant in ('w3','plaza'):
    group=bpy.data.objects[variant]
    tiers(bpy.data.objects[variant+'-blob'],anchors[variant])
    reduce_sprays(bpy.data.objects[variant+'-cards'])
swap_map(bpy.data.objects['w3-blob'].active_material,'blossom-glaze.png')
swap_map(bpy.data.objects['w3-cards'].active_material,'flower-sprays.png')

model=root/'export/mature-sakura.glb'
bpy.ops.export_scene.gltf(filepath=str(model),export_format='GLB',export_yup=True,export_extras=True,export_vertex_color='ACTIVE',export_animations=False,export_cameras=False,export_lights=False)
raw=model.read_bytes()
length=struct.unpack_from('<I',raw,12)[0]
doc=json.loads(raw[20:20+length]);tail=raw[20+length:]
doc['asset']['copyright']='Sakuragaoka Station contributors and station-art contributors, MIT'
mask=next(m for m in doc['materials'] if m.get('alphaMode')=='MASK')
mask['alphaCutoff']=.48
head=json.dumps(doc,separators=(',',':')).encode();head+=b' '*(-len(head)%4)
model.write_bytes(struct.pack('<4sII',b'glTF',2,20+len(head)+len(tail))+struct.pack('<I4s',len(head),b'JSON')+head+tail)
# Editing view separates the variants while preserving each stem's local origin.
bpy.data.objects['w3'].location.x=-10
bpy.data.objects['plaza'].location.x=10
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_distance=36
        area.spaces.active.region_3d.view_location=(0,0,5)
        area.spaces.active.shading.type='MATERIAL'
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.wm.save_as_mainfile(filepath=str(root/'source/station-cherries.blend'),compress=True)
