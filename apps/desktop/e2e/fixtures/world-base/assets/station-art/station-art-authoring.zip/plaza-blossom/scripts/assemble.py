"""Splice the plaza crown buffers and its independent image, preserving the other tree."""
from pathlib import Path
import argparse, copy, hashlib, io, json, struct
import numpy as np
from PIL import Image
args=argparse.ArgumentParser()
for name in ('base','parts','atlas','output','report'):
    args.add_argument('--'+name,required=True,type=Path)
opts=args.parse_args()
base=opts.base
sha=lambda b:hashlib.sha256(b).hexdigest()
class GLB:
    def __init__(self,path):
        raw=path.read_bytes();size=struct.unpack_from('<I',raw,12)[0]
        self.doc=json.loads(raw[20:20+size]);self.bin=raw[28+size:]
    def view(self,i):
        v=self.doc['bufferViews'][i];a=v.get('byteOffset',0)
        return self.bin[a:a+v['byteLength']]
    def prim(self,name):
        p,=next(m for m in self.doc['meshes'] if m['name']==name)['primitives'];return p
    def roles(self,name):
        p=self.prim(name);return {**p['attributes'],'indices':p['indices']}
    def payload(self,name):
        return {k:sha(self.view(self.doc['accessors'][a]['bufferView'])) for k,a in self.roles(name).items()}
old=GLB(base);part=GLB(opts.parts);d=copy.deepcopy(old.doc)
views=[old.view(i) for i in range(len(d['bufferViews']))]
names={'plaza-blob','plaza-cards'}
for name in names:
    assert old.roles(name).keys()==part.roles(name).keys()
    for key,oi in old.roles(name).items():
        new=part.doc['accessors'][part.roles(name)[key]];vi=d['accessors'][oi]['bufferView'];ni=new['bufferView']
        d['accessors'][oi]={**new,'bufferView':vi};views[vi]=part.view(ni)
        d['bufferViews'][vi]={**part.doc['bufferViews'][ni],'buffer':0}
# Keep existing shared materials and their image bytes intact. Only plaza-cards
# points to a new copy of the mask material with the plaza-specific atlas.
image=next(im for im in part.doc['images'] if im['name']=='plaza-sprays')
png=part.view(image['bufferView'])
with Image.open(io.BytesIO(png)) as embedded,Image.open(opts.atlas) as author:
    assert embedded.size==author.size==(512,512) and np.array_equal(np.asarray(embedded),np.asarray(author))
tex=d['materials'][old.prim('plaza-cards')['material']]['pbrMetallicRoughness']['baseColorTexture']['index']
imindex=len(d['images']);texindex=len(d['textures']);matindex=len(d['materials'])
d['images'].append({**image,'bufferView':len(views)});d['bufferViews'].append({'buffer':0,'byteLength':len(png)});views.append(png)
d['textures'].append({**d['textures'][tex],'source':imindex})
mat=copy.deepcopy(d['materials'][old.prim('plaza-cards')['material']])
mat['name']='Mature cherry | plaza flowering branches'
mat['pbrMetallicRoughness']['baseColorTexture']['index']=texindex;d['materials'].append(mat)
next(m for m in d['meshes'] if m['name']=='plaza-cards')['primitives'][0]['material']=matindex
buf=bytearray()
for v,data in zip(d['bufferViews'],views):
    buf+=bytes(-len(buf)%4);v.update(byteOffset=len(buf),byteLength=len(data));buf+=data
d['buffers'][0]['byteLength']=len(buf);buf+=bytes(-len(buf)%4)
head=json.dumps(d,separators=(',',':')).encode();head+=b' '*(-len(head)%4)
dst=opts.output
dst.write_bytes(struct.pack('<4sII',b'glTF',2,28+len(head)+len(buf))+struct.pack('<I4s',len(head),b'JSON')+head+struct.pack('<I4s',len(buf),b'BIN\0')+buf)
new=GLB(dst)
assert new.doc['nodes']==old.doc['nodes'] and new.doc['scenes']==old.doc['scenes']
for k in ['materials','images','textures','samplers']:assert new.doc[k][:len(old.doc[k])]==old.doc[k]
for im in old.doc['images']:assert new.view(im['bufferView'])==old.view(im['bufferView'])
unchanged={};counts={}
for m in d['meshes']:
    name=m['name'];p=new.prim(name)
    if name not in names:
        assert p==old.prim(name) and old.payload(name)==new.payload(name);unchanged[name]=new.payload(name)
    ids=d['accessors'][p['indices']];pos=d['accessors'][p['attributes']['POSITION']]
    idx=np.frombuffer(new.view(ids['bufferView']),dtype={5123:'<u2',5125:'<u4'}[ids['componentType']]).reshape(-1,3)
    pts=np.frombuffer(new.view(pos['bufferView']),dtype='<f4').reshape(-1,3).astype(np.float64)
    assert np.isfinite(pts).all() and idx.max()<len(pts)
    a,b,c=(pts[i] for i in idx.T);areas=np.linalg.norm(np.cross(b-a,c-a),axis=1)/2
    assert (areas>5e-10).all(),name
    counts[name]=len(idx)
stats=dict(baseSHA256=sha(base.read_bytes()),sha256=sha(dst.read_bytes()),bytes=dst.stat().st_size,triangles=counts,
    totalTriangles=sum(counts.values()),primitives=len(d['meshes']),materials=len(d['materials']),unchangedAccessors=unchanged,
    existingMaterialsAndImageBytesIdentical=True,allNodesSourceGeometryAndCollidersIdentical=True,
    addedImage=dict(name=image['name'],width=512,height=512,bytes=len(png),sha256=sha(png)),degenerateTriangles=0)
opts.report.write_text(json.dumps(stats,indent=2)+'\n')
