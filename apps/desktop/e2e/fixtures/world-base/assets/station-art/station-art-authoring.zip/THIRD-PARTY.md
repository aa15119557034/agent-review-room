# 来源与许可

樱花种子、树干、树皮和种植/碰撞元数据来自 Sakuragaoka Station 的 MIT 源码，固定提交为 `4112f57208b7e29998344ca71fef74202c2b2bdd`。项目接入版本 `9cfe2de5e4199502a20f1c569fc1cee86abc2649` 生成了本包附带的母树 GLB，SHA-256 为 `d0a8a72a3da09946007d52b79ca2d30682654d5a7edca51f9909c0259894437e`。保留该输入使同事能离线重新运行造型配方。[上游源码](https://github.com/kiarashfa/sakuragaoka/tree/4112f57208b7e29998344ca71fef74202c2b2bdd) · [原作者许可](licenses/LICENSE-Sakuragaoka.txt)

项目作者在两棵树的原骨架上制作花冠、枝梢及图集。两栋建筑、洗衣店门翼、相关 Blender 场景与可执行制作脚本为项目原创，随附 MIT 许可。再分发本包及导出模型时应一并保留两个许可文件。[改作者许可](licenses/LICENSE-station-art.txt)


最终广场修订保留原树干和种植节点。分叉花枝、广场花冠与 512 × 512 的花簇图为本项目原创改作，按同一 MIT 许可提供。运行 ZIP 沿用既有归档中的完整再分发声明。[正式运行包声明](runtime-metadata/station-art-notices/THIRD-PARTY.md) · [改作者许可](licenses/LICENSE-station-art.txt)
