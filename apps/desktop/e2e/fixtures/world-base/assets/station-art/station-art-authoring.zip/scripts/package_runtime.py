"""Reproduce the reviewed offline ZIP from rebuilt GLBs and the recorded notices."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
import hashlib
import sys
root=Path(__file__).resolve().parents[1]
models=Path(sys.argv[1]);output=Path(sys.argv[2])
meta=root/'runtime-metadata'
members={p.relative_to(meta).as_posix():p.read_bytes() for p in meta.rglob('*') if p.is_file()}
names=['mature-sakura.glb','alley-workshop.glb','laundry-infill.glb','station-exchange.glb']
for name in names:
    category='mature-sakura' if name==names[0] else 'station-art'
    members['.local/'+category+'/'+name]=(models/name).read_bytes()
with ZipFile(output,'w') as z:
    for name,data in sorted(members.items()):
        info=ZipInfo(name,(2026,11,19,0,0,0))
        info.create_system=0
        info.external_attr=0x01800000
        info.compress_type=ZIP_DEFLATED
        z.writestr(info,data)
expected=(root/'expected-release.sha256').read_text(encoding='ascii').split()[0]
actual=hashlib.sha256(output.read_bytes()).hexdigest()
if actual!=expected:raise ValueError('Runtime ZIP SHA-256 mismatch: '+actual)
print('Verified runtime ZIP',actual)

