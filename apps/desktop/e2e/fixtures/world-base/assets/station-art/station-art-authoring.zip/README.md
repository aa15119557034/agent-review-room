# 站区 Blender 可编辑源

本包对应广场最终运行 ZIP `e4ed22eacde7fc320637468a794fcd99d01c0344a0458adcc214d6c78bd7b54d`。四个游戏 GLB 分别是两棵成树共用的模型、东侧交换所、后巷工房、以及洗衣店门翼所在的完整洗衣店 GLB。运行包负责游戏加载，本包供同事编辑、重新导出和校验。

## 从可编辑源导出

需要 Blender 5.2.2（内置 glTF 导出器 5.2.40）、带 NumPy、Pillow 的 Python、Node.js 24.7 及以上，以及项目的 world-base fixture 检出。以下命令在解压目录运行。路径参数可用绝对或相对路径，输出目录需位于制作包外并为空。

```text
python rebuild.py --blender <Blender可执行文件> --fixture <项目目录>/apps/desktop/e2e/fixtures/world-base --out ../fresh-export --verify
```

已核准版本带 `--verify` 时会重建完整的 `station-art-fixture.zip`，包含四份 GLB、两份清单和许可，核对发行 SHA-256。四个可发布模型文件会出现在 `../fresh-export/export/`，逐文件 SHA-256 在 `sha256.json`。中间几何、源文件重开记录、拼装及净空报告放在 `build/`。[期望哈希](expected-assets.json)

| 要修改的对象 | Blender 源文件 |
|---|---|
| 两树共用的原始骨架、树皮与第一层造型 | `station-art/source/station-cherries.blend` |
| A 主街 W3 的最终分枝、花团及花瓣 | `w3-blossom-edge/source/w3-blossom-edge.blend` |
| 最终广场树冠、花簇和独立卡片材质 | `plaza-blossom/source/plaza-blossom.blend` |
| 东侧交换所和巷后工房 | `station-art/source/station-buildings.blend` |
| 洗衣店三组构件及左翼竖缝背衬 | `w3-blossom-edge/source/laundry-support.blend` |

保留对象及材质角色名。导出器会将编辑视图里分开的树和楼重新对齐各自的本地原点，导出带顶点色的几何。树冠拼装保留两棵树的原有种子、碰撞数据、树皮和材质布局。编辑新的形状后，先运行相同命令并省略 `--verify`，检查净空及新哈希，验收后再更新 [期望哈希](expected-assets.json)。

## 从配方重建编辑场景

```text
python regenerate.py --blender <Blender可执行文件> --fixture <项目目录>/apps/desktop/e2e/fixtures/world-base --out ../fresh-recipes
python rebuild.py --blender <Blender可执行文件> --fixture <项目目录>/apps/desktop/e2e/fixtures/world-base --scenes ../fresh-recipes --out ../recipe-export --verify
```

配方会在 `../fresh-recipes` 使用固定种子、母树 GLB、枝端锚点、W3 净空采样和花冠贴图重做五份编辑文件。楼体尺寸与顶点色来自 `station-art/scripts/build_buildings.py`。门翼最终修订复用其中的构件，保留原脚本字节及校验值。W3 花冠改作使用 `w3-blossom-edge/scripts/build.py`。三张材质图已打包进相应的 Blender 场景。用于重画两个花冠纹理的 `station-art/scripts/paint.py` 需要 Pillow。

## 广场花枝与 W3 材质

`plaza-blossom/scripts/survey.mjs` 用给定的 fixture 重取六条主枝和冠底净空。`paint_sprays.py` 用固定种子重画 512 × 512 图集，两者在从配方重建时都会与已交付源数据逐字节比对。Blender 先从广场 .blend 导出 `plaza-blob` 和 `plaza-cards`，随后广场拼装器单独附加一张图像、纹理和材质，并只重绑广场卡片。它检查 W3 三组几何、既有图像、材质、种植节点和碰撞元数据保持一致；检查明细位于导出结果的 `build/plaza-assembly.json`。

运行包组装使用四个新导出的 GLB 和 `runtime-metadata/` 中的正式清单与许可，固定 ZIP 成员顺序、成员时间、压缩类型和系统标识。可核对 [四件模型 SHA-256](expected-assets.json) 和 [完整 ZIP SHA-256](expected-release.sha256)。[来源与许可](THIRD-PARTY.md)
