"""Paint a four-spray atlas and a seamless low-frequency glaze in sRGB."""
from pathlib import Path
from PIL import Image, ImageDraw
import math
import random

out = Path(__file__).resolve().parents[1] / 'paint'
out.mkdir(exist_ok=True)
rng = random.Random(252)
S = 3
atlas = Image.new('RGBA', (512*S,512*S))
pen = ImageDraw.Draw(atlas)
def polygon(points, colour):
    pen.polygon([(round(x*S),round(y*S)) for x,y in points], fill=colour)

def bloom(x,y,r,angle,shade):
    palette=[('#f5b4c2','#fff0e6'),('#e89ab1','#ffd9d8'),('#e6a7b7','#ffe6de')]
    for k in range(5):
        a=angle+k*math.tau/5
        def spot(u,v):
            return x+r*(u*math.cos(a)-v*math.sin(a)),y+r*(u*math.sin(a)+v*math.cos(a))
        # Broad Japanese cherry petal with a shallow notch at the tip.
        profile=[(.03,0),(.36,-.31),(.71,-.41),(.93,-.29),(1,-.12),(.86,0),(1,.11),(.91,.29),(.7,.39),(.39,.31)]
        polygon([spot(u,v) for u,v in profile],palette[shade][k not in (1,2)])
        polygon([spot(.12,0),spot(.51,-.105),spot(.65,-.025),spot(.37,.065)],'#eab5bc')
    pen.ellipse(tuple(round(a*S) for a in (x-r*.12,y-r*.12,x+r*.12,y+r*.12)), fill='#cf8b83')

for i in range(4):
    x=(i%2)*256; y=(i//2)*256
    sites=[(64,176,31),(94,142,38),(134,111,45),(164,70,35),(174,144,29)]
    if i%2: sites=sites[1:]+[(190,54,22)]
    if i==2: sites+=[(68,100,31),(112,74,26)]
    for u,v,r in sites:
        pen.line([(S*(x+50),S*(y+211)),(S*(x+107),S*(y+151)),(S*(x+u),S*(y+v))],fill='#bc7c90',width=2*S)
    for u,v,r in sites: bloom(x+u,y+v,r,rng.random()*math.tau,rng.randrange(3))
atlas.resize((256,256),Image.Resampling.LANCZOS).save(out/'flower-sprays.png')

# Few broad, low-contrast scallops. At street distance the vertex-colour masses
# carry the crown, and the glaze resolves into petal groups only close to the tree.
tile=Image.new('RGB',(256*S,256*S),'#fffaf8')
pen=ImageDraw.Draw(tile)
for u,v,scale in [(32,75,1),(148,156,.85),(220,23,.63)]:
    for dx,dy in [(0,0),(256,0),(-256,0),(0,256),(0,-256)]:
        for a,b,r in [(0,0,14),(13,-10,10),(-12,4,9),(21,2,7)]:
            points=[]
            for t in range(60):
                phi=t*math.tau/60
                rad=r*scale*(.86-.14*math.cos(5*phi))
                points.append((u+dx+a*scale+rad*math.cos(phi),v+dy+b*scale+.79*rad*math.sin(phi)))
            polygon(points,'#f3e2e6')
tile.resize((128,128),Image.Resampling.LANCZOS).save(out/'blossom-glaze.png')
