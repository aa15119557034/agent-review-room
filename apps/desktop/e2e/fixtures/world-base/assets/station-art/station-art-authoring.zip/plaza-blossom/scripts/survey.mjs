// Recover branch directions and fork group membership before the original generator discards them.
import fs from 'node:fs';
import {registerHooks} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
import path from 'node:path';
if (!process.argv[2]) throw Error('Pass the world-base fixture checkout as the first argument');
const fixture=pathToFileURL(path.resolve(process.argv[2])+'/');
const src=new URL('upstream/sakuragaoka/src/',fixture), vendor=new URL('upstream/petalwake/vendor/three/',fixture);
const tree=new URL('world/sakura/tree.js',src).href;
registerHooks({
  resolve(s,c,next){
    if(s==='three')return {shortCircuit:true,url:new URL('build/three.module.js',vendor).href};
    if(s.startsWith('three/addons/'))return {shortCircuit:true,url:new URL('examples/jsm/'+s.slice(13),vendor).href};
    return next(s,c);
  },
  load(url,c,next){
    const m=next(url,c);if(url!==tree)return m;
    const text=fs.readFileSync(fileURLToPath(url),'utf8'),mark='const info = summarize(pads, gy, spec);';
    if(!text.includes(mark))throw Error('Unknown generator');
    return {...m,source:text.replace(mark,'env.collect(pads, limbData, branches); '+mark)};
  }
});
const core=n=>import(new URL(n+'.js',src));
const {makeTree}=await import(tree),{makePlacements}=await core('world/sakura/placements');
const {mulberry32}=await core('core/ctx'),{createNoise}=await core('world/sakura/util'),L=await core('world/layout');
const spec=makePlacements({L,rng:mulberry32,services:{houses:{}}}).trees.find(t=>t.id==='plaza');
const gy=L.heightAt(spec.x,spec.z),local=p=>[p.x-spec.x,spec.z-p.z,p.y-gy];
let report;
makeTree(spec,{rng:mulberry32, noise:createNoise(mulberry32('sakura-noise')),heightAt:L.heightAt,collect(pads,limbs,branches){
  const lobes=[...new Set(pads.map(p=>p.lobe))];
  report={pads:pads.map(p=>({tip:local(p.c).map((n,i)=>i===2?n-.3*p.ry:n),
    direction:[p.twigDir.x,-p.twigDir.z,p.twigDir.y],size:p.rx,limb:limbs.findIndex(l=>l.gp.includes(p)),
    lobe:lobes.indexOf(p.lobe)})),branches:branches.filter(b=>b.depth>=2).map(b=>b.pts.map(local))};
}});
const n=91,step=.25,origin=-11;
report.floor={origin,step,n,heights:Array.from({length:n*n},(_,i)=>+(
    spec.floorAt(spec.x+origin+(i%n)*step,spec.z-origin-Math.floor(i/n)*step)-gy).toFixed(5))};
const out=new URL('../source/',import.meta.url);fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(new URL('branch-survey.json',out),JSON.stringify(report)+'\n');
console.log(report.pads.length,'cluster tips on',new Set(report.pads.map(p=>p.limb)).size,'limbs');
