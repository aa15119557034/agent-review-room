"""Make the plaza's flower-bearing branch tips on the existing six woody limbs."""
from pathlib import Path
import bpy
import math
import random
import json
from mathutils import Vector
from mathutils.bvhtree import BVHTree

root=Path(__file__).resolve().parents[1]
for name in ['source','checks','export']: (root/name).mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root.parent/'station-art/source/station-cherries.blend'))
bpy.context.preferences.filepaths.save_version=0
for obj in [*bpy.data.objects['w3'].children,bpy.data.objects['w3']]: bpy.data.objects.remove(obj,do_unlink=True)
group=bpy.data.objects['plaza'];group.location=(0,0,0)
bark, mass, sprigs=[bpy.data.objects['plaza-'+name] for name in ['bark','blob','cards']]
bm=BVHTree.FromPolygons([v.co for v in bark.data.vertices],[tuple(f.vertices) for f in bark.data.polygons])
survey=json.loads((root/'source/branch-survey.json').read_text())
pads=survey['pads'];floor=survey['floor']
rng=random.Random(190710)
up=Vector((0,0,1));eye=Vector((1.8,-50,2.488))
def ground(p):
    c=[int(math.floor((v-floor['origin'])/floor['step'])) for v in p[:2]]
    n=floor['n'];i,j=c;assert 0<=i<n-1 and 0<=j<n-1
    a=j*n+i;return max(floor['heights'][k] for k in (a,a+1,a+n,a+n+1))
def safe(p):
    # The only surveyed keep-out is the station behind the crown, north of y=10.3.
    return p.z>ground(p)+.12 and p.y<10.12
def vec(vals):return Vector(vals)
def srgb(code):
    ch=[int(code[i:i+2],16)/255 for i in (0,2,4)]
    return [(v/12.92 if v<.04045 else ((v+.055)/1.055)**2.4) for v in ch]+[1]
class Part:
    def __init__(self):
        self.v=[];self.n=[];self.uv=[];self.color=[];self.f=[]
    def vertex(self,p,n,uv,col=None):
        self.v.append(tuple(p));self.n.append(tuple(n.normalized()));self.uv.append(uv)
        if col:self.color.append(col)
        return len(self.v)-1
    def replace(self,ob,mat):
        old=ob.data;m=bpy.data.meshes.new(ob.name+' branch fans')
        m.from_pydata(self.v,[],self.f);m.update();m.materials.append(mat)
        assert not m.validate(),ob.name
        uv=m.uv_layers.new(name='UVMap')
        for l in m.loops:uv.data[l.index].uv=self.uv[l.vertex_index]
        if self.color:
            col=m.color_attributes.new(name='Color',type='BYTE_COLOR',domain='POINT')
            for i,c in enumerate(self.color):col.data[i].color=c
        for f in m.polygons:f.use_smooth=True
        m.normals_split_custom_set_from_vertices(self.n)
        ob.data=m;bpy.data.meshes.remove(old);m.name=ob.name

solid=Part();alpha=Part()
forward=vec((1.2,61,-.4)).normalized();right=forward.cross(up).normalized();camera_up=right.cross(forward).normalized()
focal=450/math.tan(math.radians(35.63777782904556)/2)
def project(point):
    line=point-eye;depth=line.dot(forward)
    return Vector((720+focal*line.dot(right)/depth,450-focal*line.dot(camera_up)/depth))
def shoulder_gap(p):
    # Three curved forks viewed in A, with tapered openings towards their base.
    # Recede whole sprays as they approach a fork and keep the thinner tips.
    distances=[]
    for ax,ay,bx,by,top,bottom in [(494,188,524,238,19,6),(601,172,621,217,18,5),
                                   (747,185,710,239,18,6),(855,247,826,265,12,5)]:
        a=Vector((ax,ay));d=Vector((bx-ax,by-ay))
        t=max(0,min(1,(p-a).dot(d)/d.length_squared))
        distances.append((p-a-t*d).length-(top+t*(bottom-top)))
    return min(distances)
def tube(points,radii):
    spine=(points[-1]-points[0]).normalized()
    u=spine.cross(up if abs(spine.z)<.93 else vec((1,0,0))).normalized()
    v=spine.cross(u).normalized();prev=[]
    for p,r in zip(points,radii):
        ring=[]
        for j in range(5):
            n=u*math.cos(j*math.tau/5)+v*math.sin(j*math.tau/5)
            ring.append(solid.vertex(p+n*r,n,(.12,.14),srgb('856c73')))
        if prev:
            for j in range(5):
                k=(j+1)%5;solid.f.append((prev[j],prev[k],ring[k],ring[j]))
        prev=ring
def flower(p,normal,radius,tone):
    # Cupped corolla with five overlapping lobes and shallow notched tips.
    n=normal.normalized();u=n.cross(up if abs(n.z)<.91 else vec((1,0,0))).normalized()
    v=n.cross(u).normalized();rot=rng.uniform(0,math.tau)
    center=solid.vertex(p,n,(.35,.41),srgb(['ba8f9f','c89ba5','d7b4b6'][tone]))
    ring=[]
    for j in range(5):
        a=rot+j*math.tau/5;rr=radius*rng.uniform(.87,1.08)
        for angle,length in [(-.59,.35),(-.37,.77),(-.17,1.0),(0,.87),(.17,1.02),(.37,.79)]:
            d=u*math.cos(a+angle)+v*math.sin(a+angle)
            pos=p+d*(length*rr)+n*(.18*length**2*radius)
            final_n=(n-d*(.19*length)).normalized()
            colors=[['ba98a8','c4a2ad'],['d1b1bc','dec0c9'],['e2c7cb','efd7d6']]
            ring.append(solid.vertex(pos,final_n,(.44+length*.16,.17+j*.09),srgb(colors[tone][j%3==0])))
    for a,b in zip(ring,ring[1:]+ring[:1]):solid.f.append((center,a,b))

def blade(start,direction,roll,length,width,cell):
    # Slightly vaulted 3D strip with a narrow rooted end. The painted branches
    # follow its long axis. Twist leaves different vanishing angles from side views.
    d=direction.normalized()
    gap=min(shoulder_gap(project(start+d*length*k)) for k in [.36,.58,.77,.91])
    if gap<-.7:return
    if gap<14:
        fade=max(.20,min(1,(gap+.8)/15))
        width*=.48+.52*fade;length*=.64+.36*fade
        if fade<.65:cell%=8
    side=roll-d*roll.dot(d)
    if side.length<.05:return
    side.normalize()
    face=d.cross(side).normalized()
    spread=(start-vec((.4,0,6.5))).normalized()
    ns=(spread*.64+up*.66+face*.13).normalized()
    corners=[]
    for t in [0,.5,1]:
        c=start+d*(length*t)+side*(.06*length*math.sin(t*math.pi))+face*(.10*length*math.sin(t*math.pi))
        for j in [-1,1]:
            p=c+side*(j*.5*width)+face*(j*width*.11*(t-.5))
            if not safe(p):return
            u=((cell%4)+.003+.994*t)/4
            v=(4-cell//4-.002-(0 if j==1 else .996))/4
            corners.append((p,ns,(u,v)))
    ids=[alpha.vertex(*c) for c in corners]
    for i in [0,2]:alpha.f.extend([(ids[i],ids[i+2],ids[i+3]),(ids[i],ids[i+3],ids[i+1])])

lobe_centers={};limb_centers={}
for key,dest in [('lobe',lobe_centers),('limb',limb_centers)]:
    for i in {p[key] for p in pads}:
        points=[vec(p['tip']) for p in pads if p[key]==i];dest[i]=sum(points,Vector())/len(points)
stats=dict(woodTips=0,cuppedBlossoms=0,sprays=0,limbs=6)
# Keep visible air between the high central bough and both of its shoulders.
# The wood remains physically present on the lightly flowering tips.
for i,pad in enumerate(pads):
    original=vec(pad['tip']);limb=pad['limb'];lobe=pad['lobe']
    center=lobe_centers[lobe]
    tip=original.lerp(center,.30).lerp(limb_centers[limb],.07)
    d=vec(pad['direction']).normalized()
    radial=vec((tip.x-.4,tip.y,0));radial.normalize()
    d=(d*.49+radial*.62+up*rng.uniform(-.13,.26)).normalized()
    side=up.cross(d).normalized()
    flow=((tip.x-.35)*.59+math.sin(tip.y*.71)*1.25+tip.z*.53)
    taper=.72+.27*math.sin(flow)
    if i%11==0 or (taper<.50 and i%4!=0):continue
    # There are genuine branches in the input bark; bind the twig to the nearest
    # surface at an interior point so no isolated bouquets hover at the edge.
    origin=bm.find_nearest(tip-d*.72)[0]
    start=origin.lerp(tip,.53)+up*.12
    if not all(safe(p) for p in (tip,start,origin)):continue
    tube([origin,start,tip],[.050,.036,.017]);stats['woodTips']+=1
    scale=(1.65+.53*math.sin(lobe*2.3)+rng.uniform(-.17,.25))*taper
    if limb==5:scale*=1.10
    for k in range(3 if taper>.67 else 2):
        sign=(-1,1,1)[k]
        heading=(d*.73+side*(sign*(.46 if k!=2 else -.12))+up*rng.uniform(-.35,.47)).normalized()
        inner=tip if k==2 else start.lerp(tip,.35+.30*k)
        ext=scale*rng.uniform(1.04,1.35)*(1 if k==0 else .82 if k==1 else .68)
        # A splayed second fork, sometimes shown almost edge-on, makes bank depth legible.
        normal=(eye-inner).normalized()*.53+(radial*.66+up*.18)*(.44 if k!=1 else .82)
        normal+=vec((rng.uniform(-.3,.3),rng.uniform(-.3,.3),rng.uniform(-.37,.42)))
        roll=normal.cross(heading).normalized()
        if k==1:roll=(roll*.40+side*.65+up*rng.uniform(-.6,.6)).normalized()
        shade=1 if (tip.z<7.1 or (k==1 and i%3!=0) or (k==0 and lobe%4==2)) else 0
        cell=(lobe+i+k*3)%4+shade*4+(8 if k==0 or (k==1 and i%3) else 0)
        if cell>=8:ext*=1.26
        blade(inner-heading*.10,heading,roll,ext,ext*rng.uniform(.94,1.28),cell)
    if taper>.53 and i%4!=0:
        n=((eye-tip).normalized()*.70+radial*.23+up*rng.uniform(-.42,.75)).normalized()
        for k in range(1+int(i%3==1)):
            offset=(d*rng.uniform(.08,.32)+side*rng.uniform(-.19,.19)+up*rng.uniform(.04,.20))
            end=tip+offset
            if not safe(end):continue
            tube([tip,end],[.018,.008])
            flower(end,n,rng.uniform(.12,.22)*(1.28 if k==0 and i%4==1 else 1),1 if tip.z<8.5 else 2)
            stats['cuppedBlossoms']+=1
# Recessed groups sit on each secondary fork, inside the finer spray tips.
# Raise the central fan and keep separate shelves on the two lateral limbs.
for lobe,c in lobe_centers.items():
    pad=next(p for p in pads if p['lobe']==lobe);limb=pad['limb']
    interior=c.lerp(vec((.5,0,6.1)),.22)
    start=bm.find_nearest(interior)[0]
    high=limb==5 or (abs(c.x)<3.4 and c.z>8.3)
    for j in range(3 if high else 2):
        sign=1 if (c.x>.55 if not high else (j+lobe)%2==0) else -1
        d=vec((sign*rng.uniform(.55,.95),rng.uniform(-.6,.5),rng.uniform(.40,.92) if high else rng.uniform(-.17,.45))).normalized()
        ext=rng.uniform(1.65,2.5)*(1.18 if high else 1)
        front=(eye-start).normalized()+vec((rng.uniform(-.34,.34),0,rng.uniform(-.28,.45)))
        side=front.cross(d).normalized()
        point=start+d*rng.uniform(.12,.34)
        if not safe(point) or not safe(start):continue
        tube([start,point],[.040,.021])
        blade(point-d*.11,d,side,ext,ext*rng.uniform(.83,1.15),8+(lobe+j)%4+(4 if j==1 and c.z<7.6 else 0))
stats['sprays']=len(alpha.f)//4
solid.replace(mass,mass.active_material)
mat=sprigs.active_material.copy();mat.name='Mature cherry | plaza flowering branches'
im=bpy.data.images.load(str(root/'source/plaza-sprays.png'));im.pack()
for n in mat.node_tree.nodes:
    if n.type=='TEX_IMAGE':n.image=im
alpha.replace(sprigs,mat)
bpy.ops.object.select_all(action='DESELECT')
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        space=area.spaces.active;space.region_3d.view_distance=21
        space.region_3d.view_location=(0,0,5);space.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(root/'source/plaza-blossom.blend'),compress=True)
(root/'checks/authoring.json').write_text(json.dumps(stats,indent=2)+'\n')
print(stats)
