"""Rebuild the existing three laundry components and add one tile-joint backing."""
import bpy
import hashlib
import json
import sys
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = root / 'source/laundry-support.blend'
output = root / 'export/laundry-infill.glb'

def export(path):
    group = bpy.data.objects['Laundry infill']
    bpy.ops.object.select_all(action='DESELECT')
    for obj in [group, *group.children]:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = group
    bpy.ops.export_scene.gltf(filepath=str(path), export_format='GLB', use_selection=True,
        export_yup=True, export_vertex_color='ACTIVE', export_animations=False,
        export_lights=False, export_cameras=False)

if '--check' in sys.argv:
    bpy.ops.wm.open_mainfile(filepath=str(source))
    meshes = [ob for ob in bpy.context.scene.objects if ob.type == 'MESH']
    assert {m.name for m in meshes} == {'Portal_wings', 'Shell', 'Front_cassette'}
    assert not bpy.data.libraries and all(not m.modifiers and not m.data.validate() for m in meshes)
    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / output.name
        export(copy)
        assert copy.read_bytes() == output.read_bytes()
    record = dict(sourceSHA256=hashlib.sha256(source.read_bytes()).hexdigest(),
        glbSHA256=hashlib.sha256(output.read_bytes()).hexdigest(), sourceReexportIdentical=True)
    (root/'checks/laundry-source-reopen.json').write_text(json.dumps(record, indent=2)+'\n')
else:
    # Use the exact v1 mesh and enamel recipe, including original vertex order.
    upstream = root.parent / 'station-art/scripts/build_buildings.py'
    data = upstream.read_bytes()
    assert hashlib.sha256(data).hexdigest() == '6f202ce81b190215ffe548ff2470251509c9a7372ff7c3e9bd4c882a7fc6d876'
    code = data.decode('utf-8')
    common = code[code.index('def linear('):code.index("workshop=group(")]
    laundry = code[code.index("laundry=group("):code.index("exchange=group(")]
    assert laundry.count('wings.finish()') == 1
    # index 8's nine-point support test extends 30 mm beyond its paper on each side.
    laundry = laundry.replace('wings.finish()', "b(-5.006,-4.994,1.663,2.307,-.019,-.002,'c9c7b4')\nwings.finish()")
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version = 0
    context = {'bpy': bpy}
    exec(compile(common+laundry, str(upstream), 'exec'), context)
    export(output)
    bpy.ops.object.select_all(action='DESELECT')
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.spaces.active.region_3d.view_distance = 18
            area.spaces.active.region_3d.view_location = (0, 2, 1.5)
            area.spaces.active.shading.color_type = 'VERTEX'
    bpy.ops.wm.save_as_mainfile(filepath=str(source), compress=True)
