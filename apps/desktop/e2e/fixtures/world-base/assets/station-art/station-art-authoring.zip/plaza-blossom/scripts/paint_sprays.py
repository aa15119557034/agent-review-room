"""Eight original cherry sprays for the plaza tree. The stem grows left to right."""
from pathlib import Path
import math
import random
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
size = 256
ss = 2
atlas = Image.new('RGBA', (4*size, 4*size))
for cell in range(16):
    rng = random.Random(11900+cell)
    tile = Image.new('RGBA',(size*ss,size*ss))
    pen = ImageDraw.Draw(tile)
    def coords(points):
        return [(round(x*ss),round(y*ss)) for x,y in points]
    def line(points,color,width):
        pen.line(coords(points),fill=color,width=round(width*ss),joint='curve')
    def shape(points,color):
        pen.polygon(coords(points),fill=color)
    # Each raceme has a visible axis, an unequal pair of laterals and a light tip.
    # The bottom row carries the same flowering species on recessed/shaded limbs.
    dark=cell%8>=4
    wood = '#776875' if dark else '#846f73'
    centers = ['#b88898','#c8a69d'] if dark else ['#c09aa2','#d3b9a7']
    shades = (['#ad929f','#bca0aa','#c6a8b3','#d3bcc4','#dfcbd0'] if dark else
              ['#c1a0ab','#d4b2bb','#dfc0c8','#e9ced1','#f3dedb'])
    bend=rng.choice([-1,1])*rng.uniform(.5,1.0)
    slant=rng.uniform(-25,20)
    def axis(t):
        return (17+219*t,134+slant*t+bend*21*math.sin(t*3.8))
    line([axis(k/12) for k in range(13)],wood,3.8)
    forks=[]
    for rank,(t,sign,extent) in enumerate([(.22,-1,.82),(.31,1,.68),(.47,-1,.69),(.61,1,.59),(.76,-1,.47),(.86,1,.34)]):
        if cell%4==2 and rank==2:continue
        x,y=axis(t)
        dx=rng.uniform(35,58)*extent;dy=sign*rng.uniform(56,100)*extent
        bendp=(x+dx*.36,y+dy*.22)
        line([(x,y),bendp,(x+dx,y+dy)],wood,2.6)
        forks.append((x+dx,y+dy,extent))
        if rank<4:
            forks.append((x+dx*.55+rng.uniform(-5,5),y+dy*.58,extent*.82))
    forks.extend([(*axis(t),s) for t,s in [(.41,.82),(.57,.78),(.77,.76),(.96,.56)]])
    def bloom(x,y,r):
        angle=rng.uniform(0,6.28);tone=rng.choice([0,1,1,2])
        for k in range(5):
            a=angle+k*math.tau/5
            radius=r*rng.uniform(.90,1.09)
            def pos(u,v):
                return (x+radius*(u*math.cos(a)-v*math.sin(a)),
                        y+radius*(u*math.sin(a)+v*math.cos(a)))
            profile=[(.03,.02),(.34,-.31),(.66,-.40),(.90,-.31),(1,-.13),(.86,-.005),
                     (.99,.14),(.88,.32),(.65,.39),(.37,.30)]
            shape([pos(u,v) for u,v in profile],shades[min(4,tone+(1 if k%3 else 0)+(1 if k==4 else 0))])
        pen.ellipse([round((x-r*.12)*ss), round((y-r*.12)*ss),round((x+r*.12)*ss),round((y+r*.12)*ss)],fill=centers[0])
    # Each cluster has one dominant bloom and smaller, partly overlapping faces.
    # Keep a bare neck on the two outermost forks so their silhouettes separate.
    if cell>=8:
        # Short wood carries broad, overlapping corymbs. Their lobed perimeters
        # supply the middle-distance mass underneath the more open terminal sprays.
        forks=[(77,146,.88),(109,116,1.20),(127,155,.91),(154,114,1.4),
               (184,95,1.12),(191,130,1.04),(217,107,.69)]
        if cell%4==1:forks.pop(2)
        if cell%4==2:forks[0]=(68,117,.79)
        if cell%4==3:forks[3]=(153,86,1.15)
        for x,y,s in forks:
            line([axis(.16),(x-16,137),(x,y)],wood,3.5)
    for x,y,s in forks:
        r=rng.uniform(16,24)*(s*.48+.59)
        if cell>=8:r*=1.45*s
        blooms=[(x+r*.62,y+r*.24,r*.77),(x-r*.37,y-r*.47,r*.76),(x,y,r)]
        if cell%4 in (0,1):
            blooms.insert(0,(x-r*.8,y+r*.47,r*.67))
        for xx,yy,rr in blooms:bloom(xx,yy,rr)
    atlas.paste(tile.resize((size-8,size-8),Image.Resampling.LANCZOS),((cell%4)*size+4,(cell//4)*size+4))
atlas.resize((512,512),Image.Resampling.LANCZOS).save(root/'source/plaza-sprays.png',optimize=True)
