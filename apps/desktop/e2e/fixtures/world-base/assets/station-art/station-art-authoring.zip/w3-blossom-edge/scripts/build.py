"""Author W3 only. The former delivery, plaza tree and two bark meshes are inputs."""
import bpy
import json
import math
import random
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

root=Path(__file__).resolve().parents[1]
old=root.parent/'station-art'
for d in ['checks','source','export']: (root/d).mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(old/'source/station-cherries.blend'))
bpy.context.preferences.filepaths.save_version=0
group=bpy.data.objects['w3'];group.location=(0,0,0)
blob=bpy.data.objects['w3-blob'];cards=bpy.data.objects['w3-cards']
mass_mat=blob.active_material;spray_mat=cards.active_material
pads=json.loads((old/'source/blossom-anchors.json').read_text())['w3']
floor=json.loads((root/'source/w3-floor.json').read_text())
spec=json.loads(group['sourceSpec'])
gy=json.loads(group['sourceGeometry'])['base'][1]
rng=random.Random(18042)
up=Vector((0,0,1))
camera=Vector((5.8,-10.8,10.488-8-gy))
forward=Vector((1.2,61,-.4)).normalized()
right=forward.cross(up).normalized();screenup=right.cross(forward).normalized()
focal=450/math.tan(math.radians(35.63777782904556)/2)
def ray(x,y):
    return (forward+right*((x-720)/focal)+screenup*((450-y)/focal)).normalized()
def screen(p):
    d=p-camera;z=d.dot(forward)
    return (720+focal*d.dot(right)/z,450-focal*d.dot(screenup)/z)
def safe(p,margin=.085):
    i=math.floor((p.x-floor['origin'][0])/floor['step'])
    j=math.floor((p.y-floor['origin'][1])/floor['step'])
    if not (0<=i<floor['w']-1 and 0<=j<floor['h']-1):return False
    k=j*floor['w']+i;f=floor['grid'];w=floor['w']
    if p.z<max(f[k],f[k+1],f[k+w],f[k+w+1])+margin:return False
    x=spec['x']+p.x;z=spec['z']-p.y;y=gy+p.z
    return all(not(b['x0']-margin<x<b['x1']+margin and b['z0']-margin<z<b['z1']+margin and b['y0']-margin<y<b['y1']+margin) for b in spec['keepOut'])

def linear(code):
    a=[int(code[i:i+2],16)/255 for i in (0,2,4)]
    return Vector([x/12.92 if x<.04045 else ((x+.055)/1.055)**2.4 for x in a])

# Make a continuous, gently undercut body from the original branches. Each pad
# has an irregular core and smaller shoulders; voxel union removes internal seams.
verts=[];faces=[]
def kernel(c,r,phase):
    start=len(verts);sides=15;rings=7
    verts.append(c+Vector((0,0,-r.z)))
    for j in range(1,rings):
        lat=-math.pi/2+j*math.pi/rings
        for k in range(sides):
            a=k*math.tau/sides+phase+.07*(j%2)
            edge=1+.068*math.sin(3*a+.6*phase)+.055*math.cos(5*a+1.6*phase)
            verts.append(c+Vector((r.x*edge*math.cos(a)*math.cos(lat),
                r.y*edge*math.sin(a)*math.cos(lat),r.z*(math.sin(lat)+.105*math.cos(lat)*math.sin(3*a+phase)))))
    top=len(verts);verts.append(c+Vector((0,0,r.z)))
    for k in range(sides):
        t=(k+1)%sides
        faces.append((start,start+1+t,start+1+k))
        for j in range(rings-2):
            b=start+1+j*sides;faces.append((b+k,b+t,b+t+sides,b+k+sides))
        b=start+1+(rings-2)*sides;faces.append((b+k,b+t,top))

for pad in pads:
    c=Vector(pad['center']);rx,ry,h=pad['radii'];p=pad['seed']
    kernel(c,Vector((rx*.80,ry*.85,h*.89)),p)
    for j in range(4):
        a=j*math.tau/4+p+.25*math.sin(2*j+p)
        cc=c+Vector((rx*.63*math.cos(a),ry*.63*math.sin(a),h*(-.19+.11*math.cos(j+p))))
        kernel(cc,Vector((rx*(.33+.08*rng.random()),ry*(.32+.08*rng.random()),h*(.57+.14*rng.random()))),p+j)
tmp=bpy.data.meshes.new('Flowering boughs');tmp.from_pydata(verts,[],faces);tmp.update()
ob=bpy.data.objects.new('Underlying bough volumes',tmp);bpy.context.collection.objects.link(ob)
bpy.context.view_layer.objects.active=ob;ob.select_set(True)
tmp.remesh_voxel_size=.086;tmp.use_remesh_preserve_volume=False
bpy.ops.object.voxel_remesh()
smooth=ob.modifiers.new('Unify nearby flower heads','SMOOTH');smooth.factor=.5;smooth.iterations=2
bpy.ops.object.modifier_apply(modifier=smooth.name)
ob.data.calc_loop_triangles()
dec=ob.modifiers.new('Retain curved edges','DECIMATE');dec.ratio=min(1,7650/len(ob.data.loop_triangles))
dec.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=dec.name)
mesh=ob.data;mesh.validate(verbose=True);mesh.update()
def lower_hit(x,tree):
    for y in range(228,-100,-3):
        loc,n,_,_=tree.ray_cast(camera,ray(x,y),40)
        if loc is not None:return (loc,n,y)
    return None
# Lift short sections of the underside into scalloped recesses. Later flowering
# sprays bridge some of these openings while others show sky or the overhead wires.
initial=BVHTree.FromPolygons([v.co for v in mesh.vertices],[tuple(p.vertices) for p in mesh.polygons])
cut=[]
for x in [48,101,173,227,294,491,536,576,627,688,754,807,856,994,1081,1146,1270,1357]:
    h=lower_hit(x,initial)
    if h and h[2]>-18:
        p,_,_=h;scale=(p-camera).dot(forward)/focal
        cut.append((p,scale*rng.uniform(12,21),scale*rng.uniform(7,15)))
for vert0 in mesh.vertices:
    p=vert0.co;delta=0
    for ctr,radius,depth in cut:
        d=p-ctr
        t=(d.dot(right)/radius)**2+(d.dot(screenup)/(radius*1.65))**2+(d.dot(forward)/(radius*2.2))**2
        if t<5:delta+=depth*math.exp(-1.25*t)
    vert0.co+=screenup*delta
mesh.update()
pos=[v.co.copy() for v in mesh.vertices];geo=[tuple(p.vertices) for p in mesh.polygons]
surf=[v.normal.copy() for v in mesh.vertices]
bvh=BVHTree.FromPolygons(pos,geo)
norms=[];cols=[];uvs=[]
rose=linear('d99aad');pink=linear('edb7c8');light=linear('f8ccd0')
def rgba(v):return (*v,1)
for p,n in zip(pos,surf):
    # The filled volume gets a broad gradient across a bough. Individual bumps
    # have little influence on the light direction and no painted facet edges.
    dome=Vector(((p.x-3.2)*.17,p.y*.19,(p.z-6.45)*.56)).normalized()
    normal=(dome*.68+n*.32).normalized();norms.append(normal)
    t=max(0,min(1,.48+.16*(p.z-6.5)+.075*math.sin(.7*p.x-.55*p.y)+n.z*.105))
    col=rose.lerp(pink,min(1,t/.53)).lerp(light,max(0,(t-.53)/.47))
    cols.append(rgba(col));uvs.append((p.x*.58+p.z*.12,p.y*.56+p.z*.25))
core_vertices=len(pos);core_triangles=sum(len(a)-2 for a in geo)
spray_pos=[];spray_faces=[];spray_norm=[];spray_uv=[]

def vert(p,n,col):
    pos.append(p);norms.append(n);cols.append(rgba(col));uvs.append((.72,.83))
    return len(pos)-1

def stem(a,b,r0,r1,ink):
    d=(b-a).normalized();u=d.cross(up)
    if u.length<.1:u=d.cross(right)
    u.normalize();v=d.cross(u).normalized();base=len(pos);sides=4 if r0>=.008 else 3
    for centre,r in ((a,r0),(b,r1)):
        for k in range(sides):
            n=u*math.cos(math.tau*k/sides)+v*math.sin(math.tau*k/sides)
            vert(centre+n*r,n,ink)
    for k in range(sides):
        j=(k+1)%sides;geo.append((base+k,base+j,base+j+sides,base+k+sides))

def pedicel(a,b):
    d=b-a
    if d.length<.004:return
    d.normalize();v=d.cross(up)
    if v.length<.08:v=d.cross(right)
    v.normalize()
    for u in [v,d.cross(v)]:
        indices=[vert(a-u*.0035,u,twig),vert(a+u*.0035,u,twig),vert(b,u,twig)]
        geo.append(tuple(indices))

tones=[('e9b0c1','f6cdd4'),('dda0b2','f0bac8'),('f0bfca','f8d9d6'),('dba4b7','edc1ce')]
def flower(c,r,n,rotation,index):
    lo,hi=[linear(h) for h in tones[index%len(tones)]]
    v=up-n*n.dot(up)
    if v.length<.1:v=right-n*n.dot(right)
    v.normalize();u=v.cross(n).normalized()
    heart=[]
    for j in range(5):
        ang=rotation+j*math.tau/5
        along=u*math.cos(ang)+v*math.sin(ang);side=n.cross(along)
        # Each petal has a visible cleft and shallow cup. Colour changes
        # within the flower are softer than the separation between sprays.
        ring=[]
        for a,b,h in [(.08,0,0),(.56,-.34,.10),(.97,-.19,.17),
                       (.82,0,.13),(1,.15,.19),(.61,.33,.11)]:
            ring.append(vert(c+r*(along*a+side*b+n*h),n,lo.lerp(hi,min(1,.13+.68*a+.2*b))))
        geo.append(tuple(ring))
        heart.append(vert(c+r*along*.105+n*r*.023,n,linear('c78f92')))
    geo.append(tuple(heart))

def spray_card(c,d,n,width,cell):
    # The original four-cell atlas supplies secondary buds on the same twigs.
    d=(d-n*d.dot(n)).normalized()
    u=d.cross(n).normalized();v=n.cross(u).normalized()
    corners=[c-u*width/2-v*width/2,c+u*width/2-v*width/2,c+u*width/2+v*width/2,c-u*width/2+v*width/2]
    if not all(safe(q) for q in corners):return
    base=len(spray_pos);spray_pos.extend(corners);spray_norm.extend([n]*4)
    a,b=cell%2/2,cell//2/2;spray_uv.extend([(a,b),(a+.5,b),(a+.5,b+.5),(a,b+.5)])
    spray_faces.append((base,base+1,base+2,base+3))

counts={'edgeSprays':0,'individualFlowers':0,'backgroundCards':0}
ink=linear('8d636d');twig=linear('ad808a')
def flowering_tip(p,n,extent,lean,hero):
    view=(camera-p).normalized()
    across=right*lean + screenup*(-1+.18*rng.random())+view*rng.uniform(.03,.35)
    axis=(across.normalized()*.82+n*.18).normalized()
    a=p-axis*.075;elbow=p+axis*extent*.42+right*extent*.085
    tip=p+axis*extent
    if not all(safe(q,.13) for q in (a,elbow,tip)):return
    stem(a,elbow,.012,.008,ink);stem(elbow,tip,.008,.0038,twig)
    for j in range(2 if not hero else 3):
        t=.25+.30*j+rng.uniform(-.08,.06)
        joint=p+axis*extent*t
        side=right*rng.choice([-1,1])*.75+screenup*rng.uniform(-.3,.45)+view*rng.uniform(-.30,.33)
        end=joint+side.normalized()*extent*rng.uniform(.21,.48)
        if not safe(end,.14):continue
        stem(joint,end,.006,.0028,twig)
        if hero:
            for k in range(1+int(j==0)):
                c=end+right*(k-.35)*extent*.17+screenup*rng.uniform(-.033,.031)+view*rng.uniform(-.024,.032)
                r=extent*rng.uniform(.155,.235)
                if not safe(c,r+.08):continue
                fn=(view*rng.uniform(.50,.85)+n*.25+right*rng.uniform(-.5,.5)+screenup*rng.uniform(-.6,.25)).normalized()
                pedicel(end,c)
                flower(c,r,fn,rng.uniform(0,math.tau),rng.randrange(4));counts['individualFlowers']+=1
        else:spray_card(end,side,view,extent*.53,rng.randrange(4))
    if hero:
        flower(tip,extent*.145,(view*.9+n*.15).normalized(),rng.random()*6,2);counts['individualFlowers']+=1
        counts['edgeSprays']+=1

# Find the actual lower silhouette in the A camera's projection. Anchor each
# modeled spray onto the visible surface, leaving intentional gaps between runs.
edge=[]
for x in range(-48,1490,4):
    hit=None
    for y in range(228,-100,-4):
        loc,n,_,_=bvh.ray_cast(camera,ray(x,y),40)
        if loc is not None:
            hit=(x,y,loc,n);break
    if hit:edge.append(hit)
selected=[]
x=-23
while x<1470:
    count=rng.choice([1,2,2,3])
    sign=rng.choice([-1,1])
    for j in range(count):
        h=min(edge,key=lambda it:abs(it[0]-x))
        if h[1]>-49 and abs(h[0]-x)<10:
            xx,yy,_,_=h
            inset=rng.uniform(8,21) if j==1 else rng.uniform(1,6)
            p,n,_,_=bvh.ray_cast(camera,ray(xx,yy-inset),40)
            if p is not None:
                depth=(p-camera).dot(forward)
                size=depth/focal*rng.uniform(27,49)*(1 if j%2==0 else .73)
                flowering_tip(p,n,min(.59,max(.25,size)),sign*rng.uniform(.40,1.38),True)
                # The near heads sit *across* the meeting of solid and sky, not
                # in a string along the bare tips. Put each centre on the real
                # nearest surface so it also sits correctly from a walk camera.
                for dx,dy,pr in [(-6,-3,8.3),(4,-1.3,9.4),(10,-8,6.2)]:
                    ax=xx+dx*sign+rng.uniform(-2,2)
                    hh=min(edge,key=lambda it:abs(it[0]-ax))
                    pp,nn,_,_=bvh.ray_cast(camera,ray(ax,hh[1]+dy),40)
                    if pp is None:continue
                    vv=(camera-pp).normalized();rr=(pp-camera).dot(forward)/focal*pr*rng.uniform(.80,1.14)
                    cc=pp+vv*rr*.48
                    if safe(cc,rr+.079):
                        fn=(vv*.76+nn*.18+right*rng.uniform(-.48,.48)+screenup*rng.uniform(-.35,.25)).normalized()
                        pedicel(pp-vv*.01,cc)
                        flower(cc,rr,fn,rng.random()*math.tau,rng.randrange(4));counts['individualFlowers']+=1
                selected.append([xx,yy])
        x+=rng.uniform(9,17)
    x+=rng.uniform(10,34)

# Smaller flowering twigs also wrap the reverse and upper surfaces. The atlas
# has transparent gaps between heads; no layer of cards covers the interior.
for pad in pads:
    c=Vector(pad['center']);d=Vector((c.x-3.1,c.y,(c.z-6.9)*1.7))
    if d.length<.1:continue
    d.normalize();p,n,_,_=bvh.ray_cast(c+d*2.3,-d,3.15)
    if p is None or (p-c).length>1.25:continue
    v=(camera-p).normalized()
    screenxy=screen(p)
    # Keep secondary texture density low on the camera-facing fringe.
    if -10<screenxy[0]<1450 and -15<screenxy[1]<220 and rng.random()<.68:continue
    flowering_tip(p,n,rng.uniform(.25,.41),rng.uniform(-1.4,1.4),False)

counts['backgroundCards']=len(spray_faces)
def replace(target,pts,faces,normals,uvcoords,mat,colour=None):
    m=bpy.data.meshes.new(target.name+' edge study');m.from_pydata(pts,[],faces);m.materials.append(mat);m.update()
    oldmesh=target.data;target.data=m;bpy.data.meshes.remove(oldmesh);m.name=target.name
    uv=m.uv_layers.new(name='UVMap')
    for loop in m.loops:uv.data[loop.index].uv=uvcoords[loop.vertex_index]
    for f in m.polygons:f.use_smooth=True
    if colour:
        col=m.color_attributes.new(name='Color',type='BYTE_COLOR',domain='POINT')
        for i,c in enumerate(colour):col.data[i].color=c
    m.normals_split_custom_set_from_vertices(normals)
replace(blob,pos,geo,norms,uvs,mass_mat,cols)
replace(cards,spray_pos,spray_faces,spray_norm,spray_uv,spray_mat)
bpy.data.objects.remove(ob,do_unlink=True)
# Only changed primitives will be spliced into the previous game asset.
bpy.ops.object.select_all(action='DESELECT')
for o in [blob,cards]:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(root/'source/changed-parts.glb'),use_selection=True,
    export_format='GLB',export_yup=True,export_vertex_color='ACTIVE',export_extras=True,export_animations=False)
plaza=bpy.data.objects['plaza']
for o in [*plaza.children,plaza]:bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.object.select_all(action='DESELECT')
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_distance=18
        area.spaces.active.region_3d.view_location=(1,0,5)
bpy.ops.wm.save_as_mainfile(filepath=str(root/'source/w3-blossom-edge.blend'),compress=True)
counts.update(coreTriangles=core_triangles,coreVertices=core_vertices,edgeSamplePixels=selected)
(root/'checks/authoring.json').write_text(json.dumps(counts,indent=2)+'\n')
print({k:v for k,v in counts.items() if k!='edgeSamplePixels'})
