"""Export the four editable Blender scenes to an independent output directory."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import sys
import bpy

args=argparse.ArgumentParser()
args.add_argument("pack",type=Path)
args.add_argument("out",type=Path)
o=args.parse_args(sys.argv[sys.argv.index("--")+1:])
pack=o.pack.resolve()
out=o.out.resolve()
out.mkdir(parents=True,exist_ok=True)
records=[]

def open_source(filename):
    source=pack/filename
    bpy.ops.wm.open_mainfile(filepath=str(source))
    images={im.name:bool(im.packed_file) for im in bpy.data.images if im.source=='FILE' and im.users}
    modifiers=[(obj.name,m.name) for obj in bpy.context.scene.objects for m in obj.modifiers]
    if bpy.data.libraries or modifiers or not all(images.values()):
        raise ValueError(f"External library, external image or unapplied modifier in {filename}: {images}, {modifiers}")
    records.append({"source":filename,"sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"packed":images,"meshes":[x.name for x in bpy.context.scene.objects if x.type=='MESH']})

def export(filename,objects=None,extras=False,tree_parts=False):
    if objects is not None:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:obj.select_set(True)
        bpy.context.view_layer.objects.active=objects[0]
    options=dict(filepath=str(out/filename),export_format='GLB',export_yup=True,
                 export_vertex_color='ACTIVE',export_animations=False)
    if objects is not None:options['use_selection']=True
    if extras:options['export_extras']=True
    if not tree_parts:options.update(export_cameras=False,export_lights=False)
    bpy.ops.export_scene.gltf(**options)

open_source('station-art/source/station-buildings.blend')
for name,filename in [('Alley workshop','alley-workshop.glb'),('Station exchange','station-exchange.glb')]:
    obj=bpy.data.objects[name]
    obj.location.x=0  # Authoring view separates these groups horizontally.
    export(filename,[obj,*obj.children])

open_source('w3-blossom-edge/source/laundry-support.blend')
obj=bpy.data.objects['Laundry infill']
export('laundry-infill.glb',[obj,*obj.children])

open_source('station-art/source/station-cherries.blend')
for name in ('w3','plaza'):bpy.data.objects[name].location.x=0
export('mature-base.glb',extras=True)
# Apply the two source metadata edits made after the original Blender export.
base=out/'mature-base.glb'
raw=base.read_bytes()
size=struct.unpack_from('<I',raw,12)[0]
doc=json.loads(raw[20:20+size])
tail=raw[20+size:]
doc['asset']['copyright']='Sakuragaoka Station contributors and station-art contributors, MIT'
next(m for m in doc['materials'] if m.get('alphaMode')=='MASK')['alphaCutoff']=.48
header=json.dumps(doc,separators=(',',':')).encode()
header+=b' '*(-len(header)%4)
base.write_bytes(struct.pack('<4sII',b'glTF',2,20+len(header)+len(tail))+struct.pack('<I4s',len(header),b'JSON')+header+tail)

open_source('w3-blossom-edge/source/w3-blossom-edge.blend')
export('w3-parts.glb',[bpy.data.objects[n] for n in ('w3-blob','w3-cards')],extras=True,tree_parts=True)
open_source('plaza-blossom/source/plaza-blossom.blend')
export('plaza-parts.glb',[bpy.data.objects[n] for n in ('plaza-blob','plaza-cards')],extras=True,tree_parts=True)
(out/'editable-sources.json').write_text(json.dumps({'blender':bpy.app.version_string,'sources':records},indent=2)+'\n',encoding='utf-8')

